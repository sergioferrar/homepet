<?php

namespace App\Service;

use App\DTO\FinalizarCarrinhoDTO;
use App\DTO\RegistrarVendaDTO;
use App\Entity\Cliente;
use App\Entity\Financeiro;
use App\Entity\FinanceiroPendente;
use App\Entity\Venda;
use App\Entity\VendaItem;
use App\Entity\VendaPagamento;
use App\Service\NotaFiscal\NotaFiscalServiceInterface;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;

/**
 * Serviço principal do PDV
 * Centraliza toda lógica de negócio de vendas
 * Garante isolamento por estabelecimento
 */
class PdvService
{
    private EntityManagerInterface $em;
    private TenantContext $tenantContext;
    private EstoqueService $estoqueService;
    private NotaFiscalServiceInterface $notaFiscalService;
    private LoggerInterface $logger;

    public function __construct(
        EntityManagerInterface $em,
        TenantContext $tenantContext,
        EstoqueService $estoqueService,
        NotaFiscalServiceInterface $notaFiscalService,
        LoggerInterface $logger
    ) {
        $this->em = $em;
        $this->tenantContext = $tenantContext;
        $this->estoqueService = $estoqueService;
        $this->notaFiscalService = $notaFiscalService;
        $this->logger = $logger;
    }

    /**
     * Registra nova venda no PDV
     * 
     * @param RegistrarVendaDTO $dto
     * @return array Resultado da operação com ID da venda
     * @throws \Exception
     */
    public function registrarVenda(RegistrarVendaDTO $dto): array
    {
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        // Lê as formas de pagamento de forma defensiva (?? []) para não falhar
        // caso a DTO em cache seja de uma versão anterior.
        $pagamentos = $dto->pagamentos ?? [];

        $this->em->beginTransaction();
        
        try {
            // 1. Busca cliente (se informado)
            $cliente = $this->buscarCliente($dto->clienteId);
            $nomeCliente = $cliente ? $cliente->getNome() : 'Consumidor Final';

            // 2. Valida estoque ANTES de processar
            $produtosValidados = $this->estoqueService->validarEstoque($dto->itens);

            // 3. Cria venda
            $venda = $this->criarVenda($dto, $estabelecimentoId, $nomeCliente);
            $this->em->persist($venda);
            $this->em->flush(); // Flush para obter ID da venda

            // 4. Adiciona itens e valida total (considerando o desconto aplicado)
            $totalCalculado = $this->adicionarItensVenda($venda, $dto->itens);
            $desconto = max(0, (float) ($dto->desconto ?? 0));
            $this->validarTotalVenda($totalCalculado - $desconto, $dto->total);

            // 5. Baixa estoque dos produtos
            $this->estoqueService->baixarEstoque(
                $dto->itens,
                $produtosValidados,
                $venda->getId(),
                $nomeCliente
            );

            // 5.1 Registra as formas de pagamento (pagamento dividido)
            $this->registrarPagamentos($venda, $pagamentos, $estabelecimentoId, DataVendaRetroativa::resolver($dto->dataVenda ?? null));

            // 6. CORREÇÃO: NÃO registra no financeiro aqui — apenas quando finalizar
            // O financeiro será registrado em finalizarCarrinho() do Controller
            // Isso evita duplicação quando a venda é carregada e finalizada no caixa

            // Baixa os fiados incluídos nesta venda somente após pagamento real.
            if ($this->metodoEfetivo($dto) !== 'pendente') {
                $pendenteIds = array_column(
                    array_filter($dto->itens, fn(array $item) => !empty($item['pendente_id'])),
                    'pendente_id'
                );
                $this->em->getRepository(FinanceiroPendente::class)
                    ->marcarPagos($estabelecimentoId, $pendenteIds);
            }

            $this->em->flush();
            $this->em->commit();

            $this->logger->info('Venda registrada com sucesso', [
                'venda_id' => $venda->getId(),
                'estabelecimento_id' => $estabelecimentoId,
                'total' => $dto->total
            ]);

            return [
                'ok' => true,
                'msg' => 'Venda registrada com sucesso!',
                'venda_id' => $venda->getId(),
                'total' => number_format($dto->total, 2, ',', '.')
            ];

        } catch (\Exception $e) {
            $this->em->rollback();
            
            $this->logger->error('Erro ao registrar venda', [
                'erro' => $e->getMessage(),
                'estabelecimento_id' => $estabelecimentoId
            ]);

            throw $e;
        }
    }

    /**
     * Finaliza venda em carrinho
     */
    public function finalizarCarrinho(FinalizarCarrinhoDTO $dto): array
    {
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        try {
            // Busca venda em carrinho
            $venda = $this->em->getRepository(Venda::class)->findOneBy([
                'id' => $dto->vendaId,
                'estabelecimentoId' => $estabelecimentoId,
                'status' => 'Carrinho'
            ]);

            if (!$venda) {
                return [
                    'status' => 'error',
                    'mensagem' => 'Venda não encontrada ou já finalizada.'
                ];
            }

            // Atualiza dados de pagamento da venda
            $venda->setMetodoPagamento($dto->metodoPagamento);
            $venda->setBandeiraCartao($dto->bandeiraCartao);
            $venda->setParcelas($dto->parcelas);
            $venda->setData(new \DateTime());

            if ($dto->metodoPagamento === 'pendente') {
                $venda->setStatus('Pendente');
                $this->registrarFinanceiroPendente($venda);
            } else {
                $venda->setStatus('Finalizado');
                // Registra entrada no financeiro para métodos pagos
                $nomeCliente = $venda->getCliente() ?? 'Consumidor Final';
                $itensCount  = $this->em->getRepository(\App\Entity\VendaItem::class)
                    ->count(['vendaId' => $venda->getId()]);
                $this->registrarFinanceiro($venda, $nomeCliente, $itensCount);
            }

            // Tenta emitir nota fiscal (se habilitado)
            if ($this->notaFiscalService->isDisponivel()) {
                try {
                    $resultadoNF = $this->notaFiscalService->emitir($venda);
                    $this->logger->info('Nota fiscal emitida', [
                        'venda_id' => $venda->getId(),
                        'resultado' => $resultadoNF
                    ]);
                } catch (\Exception $e) {
                    $this->logger->warning('Falha ao emitir nota fiscal', [
                        'venda_id' => $venda->getId(),
                        'erro' => $e->getMessage()
                    ]);
                }
            }

            $this->em->flush();

            return [
                'status' => 'success',
                'mensagem' => 'Venda finalizada com sucesso!'
            ];

        } catch (\Exception $e) {
            $this->logger->error('Erro ao finalizar venda', [
                'venda_id' => $dto->vendaId,
                'erro' => $e->getMessage()
            ]);

            return [
                'status' => 'error',
                'mensagem' => 'Erro ao finalizar venda: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Busca cliente por ID com validação de tenant
     */
    private function buscarCliente(?int $clienteId): ?Cliente
    {
        if (!$clienteId) {
            return null;
        }

        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        return $this->em->getRepository(Cliente::class)->findOneBy([
            'id' => $clienteId,
            'estabelecimentoId' => $estabelecimentoId
        ]);
    }

    /**
     * Cria entidade Venda
     */
    private function criarVenda(RegistrarVendaDTO $dto, int $estabelecimentoId, string $nomeCliente): Venda
    {
        $venda = new Venda();
        $venda->setEstabelecimentoId($estabelecimentoId);
        $venda->setCliente($nomeCliente);
        $venda->setTotal($dto->total);
        $venda->setMetodoPagamento($this->metodoEfetivo($dto));
        $venda->setData(DataVendaRetroativa::resolver($dto->dataVenda ?? null) ?? new \DateTime());
        $venda->setOrigem($dto->origem);
        $venda->setStatus('Carrinho');

        if ($dto->troco !== null) {
            $venda->setTroco($dto->troco);
        }
        if ($dto->bandeira !== null) {
            $venda->setBandeiraCartao($dto->bandeira);
        }
        if ($dto->parcelas !== null) {
            $venda->setParcelas($dto->parcelas);
        }
        if ($dto->observacao !== null) {
            $venda->setObservacao($dto->observacao);
        }
        if ($dto->petId !== null) {
            $venda->setPetId($dto->petId);
        }

        return $venda;
    }

    /**
     * Adiciona itens à venda e retorna total calculado.
     *
     * Estrutura esperada de cada $item (vinda do frontend):
     *   id         => 'prod_5' | 'serv_3'   (prefixo + ID numérico)
     *   nome       => 'Nome do Produto'
     *   quantidade => int
     *   valor      => float (preço unitário)
     *   tipo       => 'Produto' | 'Servico'
     */
    private function adicionarItensVenda(Venda $venda, array $itens): float
    {
        $totalCalculado = 0;

        foreach ($itens as $item) {
            // Extrai o ID numérico real do produto/serviço removendo o prefixo
            $produtoId = $this->extrairIdNumerico($item['id'] ?? '');

            $vendaItem = new VendaItem();
            $vendaItem->setVendaId($venda->getId());
            $vendaItem->setProdutoId($produtoId ?: null);      // ID numérico para JOIN/estoque
            $vendaItem->setProdutoNome($item['nome']);          // snapshot do nome
            $vendaItem->setQuantidade((int)$item['quantidade']);
            $vendaItem->setPrecoUnitario((float)$item['valor']);
            $vendaItem->setTipo($item['tipo']);                 // normalizado para lowercase na entity

            $subtotal = (float)$item['quantidade'] * (float)$item['valor'];
            $vendaItem->setSubtotal($subtotal);
            $totalCalculado += $subtotal;

            $this->em->persist($vendaItem);
        }

        return $totalCalculado;
    }

    /**
     * Extrai ID numérico de strings como 'prod_5', 'serv_12' ou '5'.
     */
    private function extrairIdNumerico(string $id): int
    {
        return (int)preg_replace('/^[a-z]+_/', '', $id);
    }

    /**
     * Valida se total calculado bate com o informado
     */
    private function validarTotalVenda(float $totalCalculado, float $totalInformado): void
    {
        if (abs($totalCalculado - $totalInformado) > 0.01) {
            throw new \RuntimeException(
                "Divergência no total. " .
                "Calculado: R$ " . number_format($totalCalculado, 2, ',', '.') .
                " | Informado: R$ " . number_format($totalInformado, 2, ',', '.')
            );
        }
    }

    /**
     * Registra venda no financeiro
     * CORREÇÃO: Agora apenas registra quando a venda é finalizada (status != Carrinho)
     */
    private function registrarFinanceiro(Venda $venda, string $nomeCliente, int $qtdItens, array $pagamentos = []): void
    {
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $descricao = "Venda PDV - {$nomeCliente} | {$qtdItens} item(ns)";

        if ($venda->getMetodoPagamento() === 'pendente') {
            $finPendente = new FinanceiroPendente();
            $finPendente->setDescricao($descricao);
            $finPendente->setValor($venda->getTotal());
            $finPendente->setData(new \DateTime());
            $finPendente->setMetodoPagamento($venda->getMetodoPagamento());
            $finPendente->setEstabelecimentoId($estabelecimentoId);
            $finPendente->setOrigem('PDV');
            $finPendente->setStatus('Pendente');
            
            if ($venda->getPetId()) {
                $finPendente->setPetId($venda->getPetId());
            }

            $this->em->persist($finPendente);
            return;
        }

        // Pagamento dividido: um lançamento no financeiro por forma, para que
        // os relatórios (fechamento de caixa) separem corretamente pix, cartão etc.
        if (!empty($pagamentos)) {
            foreach ($pagamentos as $p) {
                $financeiro = new Financeiro();
                $financeiro->setDescricao($descricao . ' (' . ucfirst($p['metodo']) . ')');
                $financeiro->setValor((float) $p['valor']);
                $financeiro->setData(new \DateTime());
                $financeiro->setMetodoPagamento($p['metodo']);
                $financeiro->setOrigem('PDV');
                $financeiro->setStatus('Pago');
                $financeiro->setTipo('ENTRADA');
                $financeiro->setEstabelecimentoId($estabelecimentoId);
                $this->em->persist($financeiro);
            }
            return;
        }

        // Pagamento simples (comportamento original)
        $financeiro = new Financeiro();
        $financeiro->setDescricao($descricao);
        $financeiro->setValor($venda->getTotal());
        $financeiro->setData(new \DateTime());
        $financeiro->setMetodoPagamento($venda->getMetodoPagamento());
        $financeiro->setOrigem('PDV');
        $financeiro->setStatus('Pago');
        $financeiro->setTipo('ENTRADA');
        $financeiro->setEstabelecimentoId($estabelecimentoId);

        $this->em->persist($financeiro);
    }

    /**
     * Define o método de pagamento gravado na própria venda:
     * 'multiplo' quando há mais de uma forma; caso contrário, a forma única.
     */
    private function metodoEfetivo(RegistrarVendaDTO $dto): string
    {
        $pagamentos = $dto->pagamentos ?? [];
        if (empty($pagamentos)) {
            return $dto->metodo;
        }
        if (count($pagamentos) === 1) {
            return $pagamentos[0]['metodo'];
        }
        return 'multiplo';
    }

    /**
     * Persiste as formas de pagamento (pagamento dividido) da venda.
     * Não faz nada quando a venda tem forma única.
     */
    private function registrarPagamentos(Venda $venda, array $pagamentos, int $estabelecimentoId, ?\DateTime $data = null): void
    {
        if (empty($pagamentos)) {
            return;
        }

        foreach ($pagamentos as $p) {
            $pagamento = new VendaPagamento();
            $pagamento->setEstabelecimentoId($estabelecimentoId);
            $pagamento->setVendaId($venda->getId());
            $pagamento->setMetodo($p['metodo']);
            $pagamento->setValor((float) $p['valor']);
            $pagamento->setBandeiraCartao($p['bandeira'] ?? null);
            $pagamento->setParcelas($p['parcelas'] ?? null);
            $pagamento->setData($data ?? new \DateTime());
            $this->em->persist($pagamento);
        }
    }

    /**
     * Registra financeiro pendente na finalização de carrinho
     */
    private function registrarFinanceiroPendente(Venda $venda): void
    {
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        $finPendente = new FinanceiroPendente();
        $finPendente->setDescricao(
            'Venda ' . ucfirst($venda->getOrigem()) . ' - Pet ID: ' . $venda->getPetId()
        );
        $finPendente->setValor($venda->getTotal());
        $finPendente->setData(new \DateTime());
        $finPendente->setPetId($venda->getPetId());
        $finPendente->setEstabelecimentoId($estabelecimentoId);
        $finPendente->setMetodoPagamento('pendente');
        $finPendente->setStatus('Pendente');
        $finPendente->setOrigem($venda->getOrigem());

        $this->em->persist($finPendente);
    }
}