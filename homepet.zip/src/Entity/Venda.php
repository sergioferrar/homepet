<?php

namespace App\Entity;

use App\Repository\VendaRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=VendaRepository::class)
 * @ORM\Table(name="venda")
 */
class Venda
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /** @ORM\Column(type="integer", name="estabelecimento_id") */
    private $estabelecimentoId;

    /** @ORM\Column(type="string", length=255) */
    private $cliente;

    /** @ORM\Column(type="decimal", precision=10, scale=2) */
    private $total;

    /** @ORM\Column(type="decimal", precision=10, scale=2, nullable=true) */
    private $troco;

    /** @ORM\Column(type="string", length=50, name="metodo_pagamento") */
    private $metodoPagamento;

    /** @ORM\Column(type="string", length=50, nullable=true, name="bandeira_cartao") */
    private $bandeiraCartao;

    /** @ORM\Column(type="integer", nullable=true) */
    private $parcelas;

    /** @ORM\Column(type="datetime") */
    private $data;

    /** @ORM\Column(type="text", nullable=true) */
    private $observacao;

    /** @ORM\Column(type="integer", nullable=true, name="pet_id") */
    private $petId;

    /**
     * Atendimento (consulta) ao qual esta venda pertence.
     * Nulo para vendas avulsas / PDV sem atendimento vinculado.
     *
     * @ORM\Column(type="integer", nullable=true, name="consulta_id")
     */
    private $consultaId;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $origem;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $status;

    /**
     * Veterinário responsável pela venda (atende e recebe comissão).
     * @ORM\Column(type="integer", nullable=true, name="veterinario_id")
     */
    private $veterinarioId;

    /**
     * % de comissão aplicado nesta venda. Pode ser ajustado item a item,
     * mas este campo guarda o valor global exibido no relatório.
     * @ORM\Column(type="decimal", precision=5, scale=2, nullable=true, name="comissao_percentual")
     */
    private $comissaoPercentual;

    // --- Getters e Setters ---

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEstabelecimentoId(): ?int
    {
        return $this->estabelecimentoId;
    }

    public function setEstabelecimentoId(int $id): self
    {
        $this->estabelecimentoId = $id;
        return $this;
    }

    public function getCliente(): ?string
    {
        return $this->cliente;
    }

    public function setCliente(string $cliente): self
    {
        $this->cliente = $cliente;
        return $this;
    }

    public function getTotal(): ?float
    {
        return (float)$this->total;
    }

    public function setTotal(float $total): self
    {
        $this->total = $total;
        return $this;
    }

    public function getTroco(): ?float
    {
        return (float)$this->troco;
    }

    public function setTroco(?float $troco): self
    {
        $this->troco = $troco;
        return $this;
    }

    public function getMetodoPagamento(): ?string
    {
        return $this->metodoPagamento;
    }

    public function setMetodoPagamento(string $metodo): self
    {
        $this->metodoPagamento = $metodo;
        return $this;
    }

    public function getBandeiraCartao(): ?string
    {
        return $this->bandeiraCartao;
    }

    public function setBandeiraCartao(?string $bandeira): self
    {
        $this->bandeiraCartao = $bandeira;
        return $this;
    }

    public function getParcelas(): ?int
    {
        return $this->parcelas;
    }

    public function setParcelas(?int $parcelas): self
    {
        $this->parcelas = $parcelas;
        return $this;
    }

    public function getData(): ?\DateTimeInterface
    {
        return $this->data;
    }

    public function setData(\DateTimeInterface $data): self
    {
        $this->data = $data;
        return $this;
    }

    public function getObservacao(): ?string
    {
        return $this->observacao;
    }

    public function setObservacao(?string $obs): self
    {
        $this->observacao = $obs;
        return $this;
    }

    public function getPetId(): ?int
    {
        return $this->petId;
    }

    public function setPetId(?int $petId): self
    {
        $this->petId = $petId;
        return $this;
    }

    public function getConsultaId(): ?int
    {
        return $this->consultaId;
    }

    public function setConsultaId(?int $consultaId): self
    {
        $this->consultaId = $consultaId;
        return $this;
    }

    public function getOrigem(): ?string
    {
        return $this->origem;
    }

    public function setOrigem(string $origem): self
    {
        $this->origem = $origem;

        return $this;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(string $status): self
    {
        $this->status = $status;

        return $this;
    }

    public function getVeterinarioId(): ?int
    {
        return $this->veterinarioId;
    }

    public function setVeterinarioId(?int $vetId): self
    {
        $this->veterinarioId = $vetId;
        return $this;
    }

    public function getComissaoPercentual(): ?float
    {
        return $this->comissaoPercentual !== null ? (float) $this->comissaoPercentual : null;
    }

    public function setComissaoPercentual(?float $percentual): self
    {
        $this->comissaoPercentual = $percentual;
        return $this;
    }
}
