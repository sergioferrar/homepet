<?php

namespace App\Repository;

use App\Entity\VendaItem;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class VendaItemRepository extends ServiceEntityRepository
{
    private $conn;

    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, VendaItem::class);
        $this->conn = $this->getEntityManager()->getConnection();
    }

    /**
     * Itens de uma venda com dados do produto via LEFT JOIN
     */
    public function findByVendaId(int $vendaId): array
    {
        $sql = "SELECT vi.id, vi.venda_id, vi.produto_id, vi.produto AS produto_nome_snapshot,
                       vi.quantidade, vi.preco_unitario, vi.subtotal,
                       p.nome AS produto_nome, p.codigo_barras, p.unidade_medida, p.categoria
                FROM venda_item vi
                LEFT JOIN produto p ON p.id = vi.produto_id
                WHERE vi.venda_id = :vendaId
                ORDER BY vi.id ASC";

        return $this->conn->fetchAllAssociative($sql, ['vendaId' => $vendaId]);
    }

    /**
     * Produtos mais vendidos no período
     */
    public function maisVendidos(int $estabelecimentoId, \DateTime $inicio, \DateTime $fim): array
    {
        $sql = "SELECT vi.produto AS produto,
                       vi.produto_id,
                       p.codigo_barras, p.categoria,
                       SUM(vi.quantidade) AS total_vendido,
                       SUM(vi.subtotal) AS total_valor,
                       COUNT(DISTINCT v.id) AS total_pedidos
                FROM venda_item vi
                LEFT JOIN venda v ON v.id = vi.venda_id
                LEFT JOIN produto p ON p.id = vi.produto_id
                WHERE v.estabelecimento_id = :baseId
                  AND DATE(v.data) BETWEEN :inicio AND :fim
                  AND v.status NOT IN ('Carrinho', 'Cancelada')
                GROUP BY vi.produto_id, vi.produto, p.codigo_barras, p.categoria
                ORDER BY total_vendido DESC
                LIMIT 20";

        return $this->conn->fetchAllAssociative($sql, [
            'baseId' => $estabelecimentoId,
            'inicio' => $inicio->format('Y-m-d'),
            'fim'    => $fim->format('Y-m-d'),
        ]);
    }

    /**
     * Resumo de itens vendidos por categoria no período
     */
    public function resumoPorCategoria(int $estabelecimentoId, \DateTime $inicio, \DateTime $fim): array
    {
        $sql = "SELECT COALESCE(p.categoria, 'Sem categoria') AS categoria,
                       COUNT(vi.id) AS total_itens,
                       SUM(vi.quantidade) AS quantidade_total,
                       SUM(vi.subtotal) AS valor_total
                FROM venda_item vi
                LEFT JOIN venda v ON v.id = vi.venda_id
                LEFT JOIN produto p ON p.id = vi.produto_id
                WHERE v.estabelecimento_id = :baseId
                  AND DATE(v.data) BETWEEN :inicio AND :fim
                  AND v.status NOT IN ('Carrinho', 'Cancelada')
                GROUP BY p.categoria
                ORDER BY valor_total DESC";

        return $this->conn->fetchAllAssociative($sql, [
            'baseId' => $estabelecimentoId,
            'inicio' => $inicio->format('Y-m-d'),
            'fim'    => $fim->format('Y-m-d'),
        ]);
    }

    /**
     * Insere item na venda
     */
    public function inserir(int $vendaId, int $produtoId, string $produtoNome, float $quantidade, float $precoUnitario): int
    {
        $sql = "INSERT INTO venda_item (venda_id, produto_id, produto, quantidade, preco_unitario, subtotal)
                VALUES (:venda_id, :produto_id, :produto, :quantidade, :preco_unitario, :subtotal)";

        $this->conn->executeQuery($sql, [
            'venda_id'       => $vendaId,
            'produto_id'     => $produtoId,
            'produto'        => $produtoNome,
            'quantidade'     => $quantidade,
            'preco_unitario' => $precoUnitario,
            'subtotal'       => $quantidade * $precoUnitario,
        ]);

        return (int) $this->conn->lastInsertId();
    }

    /**
     * Remove todos os itens de uma venda
     */
    public function deleteByVendaId(int $vendaId): void
    {
        $this->conn->executeQuery(
            "DELETE FROM venda_item WHERE venda_id = :vendaId",
            ['vendaId' => $vendaId]
        );
    }

    /**
     * Itens de várias vendas em UMA query, indexados por venda_id.
     *
     * Substitui o laço `findBy(['vendaId' => $id])` dentro de foreach
     * (N+1 queries + hidratação de entidade desnecessária) e devolve o
     * subtotal REAL gravado no banco — que já considera o desconto.
     *
     * @param int[] $vendaIds
     * @return array<int, array<int, array>>
     */
    public function listarPorVendas(int $baseId, array $vendaIds): array
    {
        $vendaIds = array_values(array_filter(array_map('intval', $vendaIds)));

        if ($vendaIds === []) {
            return [];
        }

        $sql = "SELECT vi.id, vi.venda_id, vi.tipo, vi.produto_id,
                       vi.produto AS produto_nome,
                       vi.quantidade, vi.valor_unitario, vi.subtotal
                FROM homepet_{$baseId}.venda_item vi
                INNER JOIN homepet_{$baseId}.venda v
                        ON v.id = vi.venda_id
                       AND v.estabelecimento_id = :estab
                WHERE vi.venda_id IN (:ids)
                ORDER BY vi.venda_id ASC, vi.id ASC";

        $linhas = $this->conn->fetchAllAssociative(
            $sql,
            ['estab' => $baseId, 'ids' => $vendaIds],
            ['ids' => \Doctrine\DBAL\ArrayParameterType::INTEGER]
        );

        $porVenda = [];

        foreach ($linhas as $linha) {
            $vendaId    = (int) $linha['venda_id'];
            $quantidade = (int) $linha['quantidade'];
            $unitario   = (float) $linha['valor_unitario'];
            $subtotal   = (float) $linha['subtotal'];

            $porVenda[$vendaId][] = [
                'id'         => (int) $linha['id'],
                'item'       => $linha['produto_nome'] ?: 'Item sem descrição',
                'tipo'       => $linha['tipo'],
                'produto_id' => $linha['produto_id'] !== null ? (int) $linha['produto_id'] : null,
                'quantidade' => $quantidade,
                'valor'      => $unitario,
                // subtotal vem do banco: unitário × qtd − desconto da linha
                'subtotal'   => $subtotal,
                'desconto'   => round(($unitario * $quantidade) - $subtotal, 2),
            ];
        }

        return $porVenda;
    }

    /**
     * Insere um item de venda (serviço ou produto) com isolamento por tenant.
     */
    public function inserirItem(int $baseId, array $dados): void
    {
        $sql = "INSERT INTO homepet_{$baseId}.venda_item
                    (venda_id, tipo, produto_id, produto, quantidade, valor_unitario, subtotal, comissao_percentual)
                VALUES
                    (:venda_id, :tipo, :produto_id, :produto, :quantidade, :valor_unitario, :subtotal, :comissao_percentual)";

        $this->conn->executeStatement($sql, [
            'venda_id'            => $dados['venda_id'],
            'tipo'                => $dados['tipo'],
            'produto_id'          => $dados['produto_id'],
            'produto'             => $dados['produto'],
            'quantidade'          => $dados['quantidade'],
            'valor_unitario'      => $dados['valor_unitario'],
            'subtotal'            => $dados['subtotal'],
            'comissao_percentual' => $dados['comissao_percentual'] ?? null,
        ]);
    }
}