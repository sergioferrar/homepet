<?php

namespace App\Repository;

use App\Entity\HospedagemCaes;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<HospedagemCaes>
 *
 * @method HospedagemCaes|null find($id, $lockMode = null, $lockVersion = null)
 * @method HospedagemCaes|null findOneBy(array $criteria, array $orderBy = null)
 * @method HospedagemCaes[]    findAll()
 * @method HospedagemCaes[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class HospedagemCaesRepository extends ServiceEntityRepository
{
    private $conn;
    private $baseId;

    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, HospedagemCaes::class);
        $this->conn = $this->getEntityManager()->getConnection();
    }


    public function insert($baseId, HospedagemCaes $h): void

    {
        $sql = "INSERT INTO homepet_{$baseId}.hospedagem_caes (estabelecimento_id, cliente_id, pet_id, data_entrada, data_saida, valor, observacoes)
                VALUES (:estabelecimento_id, :cliente_id, :pet_id, :data_entrada, :data_saida, :valor, :observacoes)";
        $this->conn->executeQuery($sql, [
            'estabelecimento_id' => $baseId,
            'cliente_id' => $h->getClienteId(),
            'pet_id' => $h->getPetId(),
            'data_entrada' => $h->getDataEntrada()->format('Y-m-d H:i:s'),
            'data_saida' => $h->getDataSaida()->format('Y-m-d H:i:s'),
            'valor' => $h->getValor(),
            'observacoes' => $h->getObservacoes(),
        ]);
    }

    public function registrarFinanceiro($baseId, HospedagemCaes $h): void

    {
        $sql = "INSERT INTO homepet_{$baseId}.financeiro (estabelecimento_id, descricao, valor, data, pet_id, pet_nome)
                VALUES (:estabelecimento_id, :descricao, :valor, NOW(), :pet_id, (SELECT nome FROM homepet_{$baseId}.pet WHERE estabelecimento_id = '{$baseId}' AND id = :pet_id LIMIT 1))";
        $this->conn->executeQuery($sql, [
            'estabelecimento_id' => $baseId,
            'descricao' => 'Hospedagem do Pet',
            'valor' => $h->getValor(),
            'pet_id' => $h->getPetId(),
        ]);
    }

    public function getClientes($baseId)
    {
        $sql = "SELECT * 
        FROM homepet_{$baseId}.cliente
        WHERE estabelecimento_id = '{$baseId}'
        ";

        return $this->conn->fetchAllAssociative("SELECT * FROM homepet_{$baseId}.cliente");
    }

    public function getPets($baseId): array
    {
        $sql = "SELECT 
                    p.id, 
                    p.nome, 
                    c.id AS dono_id, 
                    c.nome AS dono_nome
                FROM homepet_{$baseId}.pet p
                LEFT JOIN homepet_{$baseId}.cliente c ON c.id = p.dono_id
                WHERE p.estabelecimento_id = '{$baseId}'";

        return $this->conn->fetchAllAssociative($sql);
    }




    public function localizaTodos($baseId): array
    {
        $sql = "SELECT h.id, h.cliente_id, c.nome AS cliente_nome,
                       h.pet_id, p.nome AS pet_nome,
                       h.data_entrada, h.data_saida, h.valor, h.observacoes
                FROM homepet_{$baseId}.hospedagem_caes h
                LEFT JOIN homepet_{$baseId}.cliente c ON c.id = h.cliente_id
                LEFT JOIN homepet_{$baseId}.pet p ON p.id = h.pet_id
                WHERE h.estabelecimento_id = '{$baseId}'
                ORDER BY h.data_entrada DESC";

        return $this->conn->fetchAllAssociative($sql);
    }


    public function localizaPorId($baseId, int $id): ?array
    {
        $sql = "SELECT * 
            FROM homepet_{$baseId}.hospedagem_caes 
            WHERE estabelecimento_id = '{$baseId}' AND id = :id";

        return $this->conn->fetchAssociative($sql, ['id' => $id]) ?: null;
    }

    public function delete($baseId, int $id): void
    {
        $this->conn->executeQuery("DELETE FROM homepet_{$baseId}.hospedagem_caes WHERE estabelecimento_id = '{$baseId}' AND id = :id", ['id' => $id]);
    }


    public function updateHospedagem($baseId, int $id, HospedagemCaes $h): void
    {
        $sql = "UPDATE homepet_{$baseId}.hospedagem_caes
                SET cliente_id = :cliente_id,
                    pet_id = :pet_id,
                    data_entrada = :data_entrada,
                    data_saida = :data_saida,
                    valor = :valor,
                    observacoes = :observacoes
                WHERE estabelecimento_id = '{$baseId}' AND id = :id";

        $this->conn->executeQuery($sql, [
            'cliente_id' => $h->getClienteId(),
            'pet_id' => $h->getPetId(),
            'data_entrada' => $h->getDataEntrada()->format('Y-m-d H:i:s'),
            'data_saida' => $h->getDataSaida()->format('Y-m-d H:i:s'),
            'valor' => $h->getValor(),
            'observacoes' => $h->getObservacoes(),
            'id' => $id,
        ]);
    }

    public function localizaPorData($baseId, \DateTime $data): array
    {
        $query = "
            SELECT h.*, c.nome as cliente_nome, p.nome as pet_nome
            FROM homepet_{$baseId}.hospedagem_caes h
            INNER JOIN homepet_{$baseId}.cliente c ON c.id = h.cliente_id
            INNER JOIN homepet_{$baseId}.pet p ON p.id = h.pet_id
            WHERE h.estabelecimento_id = '{$baseId}' AND h.estabelecimento_id = '{$baseId}' AND h.data_entrada <= :data AND h.data_saida >= :data
            ORDER BY h.data_entrada ASC
        ";

        return $this->conn->fetchAllAssociative($query, [
            'data' => $data->format('Y-m-d'),
        ]);
    }





    /**
     * Retorna o nome do pet pelo ID, usado ao montar o VendaItem de hospedagem.
     */
    public function getPetNome($baseId, int $petId): string
    {
        $sql = "SELECT nome FROM homepet_{$baseId}.pet
                WHERE estabelecimento_id = :baseId AND id = :petId LIMIT 1";

        $result = $this->conn->fetchOne($sql, ['baseId' => $baseId, 'petId' => $petId]);
        return $result ?: 'Pet #' . $petId;
    }

    /**
     * Retorna o nome do cliente pelo ID, usado ao montar o cabeçalho da Venda de hospedagem.
     */
    public function getClienteNome($baseId, int $clienteId): string
    {
        $sql = "SELECT nome FROM homepet_{$baseId}.cliente
                WHERE estabelecimento_id = :baseId AND id = :clienteId LIMIT 1";

        $result = $this->conn->fetchOne($sql, ['baseId' => $baseId, 'clienteId' => $clienteId]);
        return $result ?: 'Cliente #' . $clienteId;
    }

//    /**
//     * @return HospedagemCaes[] Returns an array of HospedagemCaes objects
//     */
//    public function findByExampleField($value): array
//    {
//        return $this->createQueryBuilder('h')
//            ->andWhere('h.exampleField = :val')
//            ->setParameter('val', $value)
//            ->orderBy('h.id', 'ASC')
//            ->setMaxResults(10)
//            ->getQuery()
//            ->getResult()
//        ;
//    }

//    public function findOneBySomeField($value): ?HospedagemCaes
//    {
//        return $this->createQueryBuilder('h')
//            ->andWhere('h.exampleField = :val')
//            ->setParameter('val', $value)
//            ->getQuery()
//            ->getOneOrNullResult()
//        ;
//    }
}