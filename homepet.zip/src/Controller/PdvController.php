<?php

namespace App\Controller;

use App\DTO\RegistrarSaidaDTO;
use App\DTO\RegistrarVendaDTO;
use App\Entity\Cliente;
use App\Entity\FinanceiroPendente;
use App\Entity\Pet;
use App\Entity\Produto;
use App\Entity\Servico;
use App\Entity\Venda;
use App\Entity\VendaItem;
use App\Service\CaixaService;
use App\Service\DataVendaRetroativa;
use App\Service\NotaFiscal\AsaasNotaFiscalService;
use App\Service\NotaFiscal\NotaFiscalException;
use App\Service\PdvService;
use App\Service\TenantContext;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Controller do PDV - Apenas coordena requests, toda lógica está nos Services
 *
 * @Route("dashboard/clinica/pdv")
 */
class PdvController extends DefaultController
{

    /**
     * Tela principal do PDV
     *
     * @Route("", name="clinica_pdv_index", methods={"GET"})
     */
    public function index(EntityManagerInterface $em, Request $request): Response
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $conn = $em->getConnection();

        // ── Produtos + serviços numa consulta cada, só com as colunas usadas
        // pelo front. Evita hidratar milhares de entidades. ───────────────
        $produtosRows = $conn->fetchAllAssociative(
            "SELECT id, nome, preco_venda AS valor, estoque_atual AS estoque
             FROM homepet_{$estabelecimentoId}.produto
             WHERE estabelecimento_id = :estab",
            ['estab' => $estabelecimentoId]
        );

        $servicosRows = $conn->fetchAllAssociative(
            "SELECT id, nome, valor, descricao
             FROM homepet_{$estabelecimentoId}.servico
             WHERE estabelecimento_id = :estab",
            ['estab' => $estabelecimentoId]
        );

        $itensNormalizados = [];
        foreach ($produtosRows as $p) {
            $itensNormalizados[] = [
                'id' => 'prod_' . $p['id'],
                'nome' => $p['nome'],
                'valor' => (float) ($p['valor'] ?? 0),
                'estoque' => $p['estoque'] !== null ? (int) $p['estoque'] : 0,
                'tipo' => 'Produto',
                'descricao' => $p['nome'] ?? '',
            ];
        }
        foreach ($servicosRows as $s) {
            $itensNormalizados[] = [
                'id' => 'serv_' . $s['id'],
                'nome' => $s['nome'],
                'valor' => (float) ($s['valor'] ?? 0),
                'estoque' => null,
                'tipo' => 'Serviço',
                'descricao' => $s['descricao'] ?? '',
            ];
        }
        usort($itensNormalizados, fn($a, $b) => strcmp((string) $a['nome'], (string) $b['nome']));

        // Clientes: apenas colunas realmente exibidas no autocomplete.
        $clientesNormalizados = $conn->fetchAllAssociative(
            "SELECT id, nome, email, telefone
             FROM homepet_{$estabelecimentoId}.cliente
             WHERE estabelecimento_id = :estab
             ORDER BY nome",
            ['estab' => $estabelecimentoId]
        );

        // Vendas em carrinho
        $vendasCarrinho = $em->getRepository(Venda::class)
            ->findCarrinho($estabelecimentoId);

        // Lê (e consome) o payload da venda pré-carregada gravado por carregarVendaNopdv()
        $session = $request->getSession();
        $vendaPreCarregada = $session->get('pdv_venda_pre_carregada');
        if ($vendaPreCarregada !== null) {
            $session->remove('pdv_venda_pre_carregada');
        }

        return $this->render("clinica/pdv.html.twig", [
            'produtos' => $itensNormalizados,
            'clientes' => $clientesNormalizados,
            'vendas_carrinho' => $vendasCarrinho ?? [],
            'vendaPreCarregada' => $vendaPreCarregada, // null quando não há pré-carregamento
        ]);
    }

    /**
     * Carrega uma venda da clínica no PDV (Lançar no Caixa)
     *
     * @Route("/carregar/{id}", name="pdv_carregar", methods={"GET"})
     */
    public function carregarVendaNopdv(
        int $id,
        EntityManagerInterface $em,
        Request $request
    ): Response {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        $session = $request->getSession();

        // 1. Busca a venda garantindo que pertence ao estabelecimento
        $venda = $em->getRepository(Venda::class)->findOneBy([
            'id' => $id,
            'estabelecimentoId' => $estabelecimentoId,
        ]);

        if (!$venda) {
            $this->addFlash('danger', 'Venda não encontrada.');
            return $this->redirectToRoute('clinica_pdv_listar');
        }

        // 2. Valida status — só carrega vendas abertas / em carrinho
        $statusPermitidos = ['Aberta', 'Carrinho', 'carrinho', 'Pendente'];
        if (!in_array($venda->getStatus(), $statusPermitidos, true)) {
            $this->addFlash('warning', sprintf(
                'A venda #%d não pode ser lançada no caixa (status: %s).',
                $venda->getId(),
                $venda->getStatus()
            ));
            return $this->redirectToRoute('clinica_pdv_listar');
        }

        // 3. Busca os itens da venda
        $itensEntities = $em->getRepository(VendaItem::class)->findBy(['vendaId' => $venda->getId()]);

        // 4. Monta payload de itens para a sessão
        $itensNormalizados = $this->normalizarItensDaVenda($em, $itensEntities);

        // Se o total gravado for menor que a soma dos subtotais, significa que
        // um crédito foi aplicado antes. Mantém a diferença como desconto para
        // o PDV não cobrar o valor cheio.
        $somaSubtotais = array_sum(array_column($itensNormalizados, 'subtotal'));
        $descontoCredito = max(0.0, round($somaSubtotais - (float) $venda->getTotal(), 2));

        // 5. Resolve nome do cliente e pet (e localiza o cliente_id para crédito)
        $nomeCliente = $venda->getCliente() ?? 'Consumidor Final';
        $petId = $venda->getPetId();
        $nomePet = null;
        $clienteId = null;
        $creditoDisponivel = 0.0;

        if ($petId) {
            $pet = $em->getRepository(Pet::class)->find($petId);
            if ($pet) {
                $nomePet = $pet->getNome();
                $clienteId = method_exists($pet, 'getDono_Id') ? $pet->getDono_Id() : null;
            }
        }

        if ($clienteId) {
            $creditoDisponivel = $this->getRepositorio(\App\Entity\ClienteCreditoMovimento::class)
                ->saldoDoCliente($estabelecimentoId, (int) $clienteId);
        }

        // 6. Grava tudo na sessão — o PDV lê via Twig/JS
        $session->set('pdv_venda_pre_carregada', [
            'venda_id' => $venda->getId(),
            'cliente_nome' => $nomeCliente,
            'cliente_id' => $clienteId,
            'pet_id' => $petId,
            'pet_nome' => $nomePet,
            'itens' => $itensNormalizados,
            'total' => $venda->getTotal(),
            'observacao' => $venda->getObservacao(),
            'credito_disponivel' => round($creditoDisponivel, 2),
            'desconto_credito' => $descontoCredito,
        ]);

        $this->addFlash('success', sprintf(
            'Venda #%d carregada no PDV. Revise os itens e finalize.',
            $venda->getId()
        ));
        
        $dataRequest = [];
        $dataRequest['vendaId'] = $venda->getId();

        if($request->get('ficha')){
            $dataRequest['ficha'] = true;
        }
        // 7. Redireciona para a tela principal do PDV
        return $this->redirectToRoute('clinica_pdv_index', $dataRequest);
    }

    /**
     * Registra nova venda
     *
     * @Route("/registrar", name="clinica_pdv_registrar", methods={"POST"})
     */
    public function registrar(Request $request): JsonResponse
    {
        $this->switchDB();

        try {
            $dados = json_decode($request->getContent(), true);
            $dto = RegistrarVendaDTO::fromArray($dados);

            // Valida DTO
            $errors = $dto->validate();
            if (!empty($errors)) {
                return new JsonResponse([
                    'ok' => false,
                    'msg' => implode(' ', $errors),
                ], 400);
            }

            // Processa venda via service
            $resultado = $this->pdvService->registrarVenda($dto);

            return new JsonResponse($resultado, $resultado['ok'] ? 200 : 400);

        } catch (\Exception $e) {
            return new JsonResponse([
                'ok' => false,
                'msg' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Registra saída de caixa
     *
     * @Route("/saida", name="clinica_pdv_saida", methods={"POST"})
     */
    public function registrarSaida(Request $request): JsonResponse
    {
        $this->switchDB();

        try {
            $dados = json_decode($request->getContent(), true);
            $dto = RegistrarSaidaDTO::fromArray($dados);

            // Valida DTO
            $errors = $dto->validate();
            if (!empty($errors)) {
                return new JsonResponse([
                    'ok' => false,
                    'msg' => implode(' ', $errors),
                ], 400);
            }

            // Processa saída via service
            $resultado = $this->caixaService->registrarSaida($dto);

            return new JsonResponse($resultado, $resultado['ok'] ? 200 : 400);

        } catch (\Exception $e) {
            return new JsonResponse([
                'ok' => false,
                'msg' => 'Erro ao registrar saída: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Tela de controle de caixa
     *
     * @Route("/caixa", name="clinica_pdv_caixa", methods={"GET"})
     */
    public function caixa(): Response
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $hoje = new \DateTime();
        $vendaRepo = $this->getRepositorio(Venda::class);

        // Busca resumo do caixa
        $resumoCaixa = $this->caixaService->getResumoDoDia();

        // Busca totais de vendas
        $totais = $vendaRepo->totalPorFormaPagamento($estabelecimentoId, $hoje);
        $totalGeral = $vendaRepo->totalGeralDoDia($estabelecimentoId, $hoje);

        return $this->render('clinica/pdv_caixa.html.twig', [
            'data' => $hoje,
            'registros' => $resumoCaixa['registros'],
            'entradas' => $resumoCaixa['entradas'],
            'saidas' => $resumoCaixa['saidas'],
            'saldo' => $resumoCaixa['saldo'],
            'totais' => $totais,
            'totalGeral' => $totalGeral,
        ]);
    }

    /**
     * Listagem de vendas
     *
     * @Route("/listar", name="clinica_pdv_listar", methods={"GET"})
     */
    public function listar(EntityManagerInterface $em): Response
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $conn = $em->getConnection();

        // SQL nativo para trazer o nome do pet na mesma consulta e evitar N+1.
        $sql = "SELECT v.id,
                       v.data,
                       v.cliente,
                       v.total,
                       v.metodo_pagamento AS metodoPagamento,
                       v.status,
                       v.pet_id AS petId,
                       p.nome AS petNome
                FROM homepet_{$estabelecimentoId}.venda v
                LEFT JOIN homepet_{$estabelecimentoId}.pet p ON p.id = v.pet_id
                WHERE v.estabelecimento_id = :estab
                ORDER BY v.data DESC";

        $vendas = $conn->fetchAllAssociative($sql, ['estab' => $estabelecimentoId]);

        return $this->render('clinica/pdv_listar.html.twig', [
            'vendas' => $vendas,
        ]);
    }

    /**
     * Atendimentos/serviços em aberto do tutor, agrupados por pet, para trazer à venda.
     *
     * @Route("/pendentes-cliente/{clienteId}", name="clinica_pdv_pendentes_cliente", methods={"GET"})
     */
    public function pendentesCliente(int $clienteId): JsonResponse
    {
        $this->switchDB();
        $baseId = $this->tenantContext->getEstabelecimentoId();

        $rows = $this->getRepositorio(\App\Entity\FinanceiroPendente::class)
            ->findAbertosPorCliente($baseId, $clienteId);

        // Agrupa por pet
        $petsMap = [];
        $total = 0.0;
        foreach ($rows as $r) {
            $petId = (int) $r['pet_id'];
            if (!isset($petsMap[$petId])) {
                $petsMap[$petId] = [
                    'pet_id' => $petId,
                    'pet_nome' => $r['pet_nome'],
                    'itens' => [],
                ];
            }
            $valor = (float) $r['valor'];
            $total += $valor;
            $petsMap[$petId]['itens'][] = [
                'id' => (int) $r['id'],
                'descricao' => $r['descricao'],
                'valor' => $valor,
            ];
        }

        return new JsonResponse([
            'success' => true,
            'pets' => array_values($petsMap),
            'total' => $total,
            'quantidade' => count($rows),
        ]);
    }

    /**
     * Marca as pendências como pagas depois de incluídas numa venda.
     *
     * @Route("/baixar-pendentes", name="clinica_pdv_baixar_pendentes", methods={"POST"})
     */
    public function baixarPendentes(Request $request): JsonResponse
    {
        $this->switchDB();
        $baseId = $this->tenantContext->getEstabelecimentoId();

        $dados = json_decode($request->getContent(), true);
        $ids = $dados['ids'] ?? $request->request->all('ids');

        if (empty($ids) || !is_array($ids)) {
            return new JsonResponse(['success' => false, 'mensagem' => 'Nenhuma pendência informada.'], 400);
        }

        try {
            $this->getRepositorio(\App\Entity\FinanceiroPendente::class)->marcarPagos($baseId, $ids);
            return new JsonResponse(['success' => true]);
        } catch (\Throwable $e) {
            return new JsonResponse(['success' => false, 'mensagem' => $e->getMessage()], 500);
        }
    }

    /**
     * Lista clientes para Select2
     *
     * @Route("/clientes/listar", name="clinica_pdv_clientes_listar", methods={"GET"})
     */
    public function listarClientes(): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $clienteRepo = $this->getRepositorio(Cliente::class);

        $clientes = $clienteRepo->findBy(['estabelecimentoId' => $estabelecimentoId]);

        $resultado = array_map(fn($c) => [
            'id' => $c->getId(),
            'nome' => $c->getNome(),
            'email' => $c->getEmail(),
            'telefone' => $c->getTelefone(),
        ], $clientes);

        return new JsonResponse($resultado);
    }

    /**
     * Autocomplete de tutores
     *
     * @Route("/autocomplete/tutor", name="clinica_autocomplete_tutor", methods={"GET"})
     */
    public function autocompleteTutor(Request $request): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $query = $request->query->get('query');
        $clienteRepo = $this->getRepositorio(Cliente::class);

        if (empty($query) || strlen($query) < 3) {
            return new JsonResponse([]);
        }

        $clientes = $clienteRepo->findByNomeLike($estabelecimentoId, $query);

        $resultado = array_map(fn($c) => [
            'id' => $c['id'],
            'nome' => $c['nome'],
        ], $clientes);

        return new JsonResponse($resultado);
    }

    /**
     * Busca pets de um tutor
     *
     * @Route("/pets-by-tutor/{id}", name="clinica_pets_by_tutor", methods={"GET"})
     */
    public function getPetsByTutor(int $id): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $clienteRepo = $this->getRepositorio(Cliente::class);

        $pets = $clienteRepo->listarPetsDoCliente($estabelecimentoId, $id);

        $resultado = array_map(fn($p) => [
            'id' => $p['id'],
            'nome' => $p['nome'],
        ], $pets);

        return new JsonResponse($resultado);
    }

    /**
     * Finaliza venda em carrinho (VERSÃO CORRIGIDA)
     *
     * @Route("/carrinho/finalizar/{id}", name="pdv_finalizar_carrinho", methods={"POST"})
     * 
     * MUDANÇAS APLICADAS:
     * - Mantém o fluxo de registrar no financeiro (linhas 510-553)
     * - Compatibiliza com PdvService que NÃO registra mais no financeiro prematuro
     * - Garante registro único quando a venda é finalizada
     */
    public function finalizarCarrinho(
        Request $request,
        int $id,
        AsaasNotaFiscalService $asaas
    ): JsonResponse {
        $this->switchDB();
        $vendaRepo = $this->getRepositorio(Venda::class);
        $fpRepo = $this->getRepositorio(FinanceiroPendente::class);
 
        try {
            // Aceita JSON ou form-data
            $contentType = $request->headers->get('Content-Type', '');
            $dados = str_contains($contentType, 'application/json')
            ? (json_decode($request->getContent(), true) ?? [])
            : $request->request->all();
 
            $metodo = $dados['metodo_pagamento'] ?? '';
            $bandeira = $dados['bandeira_cartao'] ?? null;
            $parcelas = !empty($dados['parcelas']) ? (int) $dados['parcelas'] : null;
            $usarCreditoReq = isset($dados['usar_credito'])
                ? (float) str_replace(',', '.', (string) $dados['usar_credito'])
                : 0.0;
            $deixarCreditoReq = isset($dados['deixar_credito'])
                ? (float) str_replace(',', '.', (string) $dados['deixar_credito'])
                : 0.0;
 
            // Formas de pagamento divididas (opcional)
            $pagamentos = [];
            foreach ($dados['pagamentos'] ?? [] as $p) {
                $m = trim((string) ($p['metodo'] ?? ''));
                $v = (float) ($p['valor'] ?? 0);
                if ($m === '' || $v <= 0) {
                    continue;
                }
                $pagamentos[] = [
                    'metodo'   => $m,
                    'valor'    => round($v, 2),
                    'bandeira' => !empty($p['bandeira']) ? (string) $p['bandeira'] : null,
                    'parcelas' => !empty($p['parcelas']) ? (int) $p['parcelas'] : null,
                ];
            }
 
            // Se veio pagamento dividido, ele define o método efetivo da venda
            if (!empty($pagamentos)) {
                foreach ($pagamentos as $p) {
                    if ($p['metodo'] === 'pendente') {
                        return new JsonResponse([
                            'status' => 'error',
                            'mensagem' => 'Pagamento dividido não pode incluir a forma "Pendente".',
                        ], 400);
                    }
                }
                $metodo = count($pagamentos) === 1 ? $pagamentos[0]['metodo'] : 'multiplo';
            }
 
            if (empty($metodo)) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Método de pagamento não informado.',
                ], 400);
            }
 
            // Data opcional (venda esquecida): só ontem ou hoje. Nula = fluxo normal (NOW()).
            try {
                $dataVenda = DataVendaRetroativa::resolver(
                    is_string($dados['data_venda'] ?? null) ? $dados['data_venda'] : null
                );
            } catch (\InvalidArgumentException $e) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => $e->getMessage(),
                ], 400);
            }
 
            $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
 
            // Busca a venda via SQL nativo (banco do tenant correto)
            $venda = $vendaRepo->findVendaCarrinho($estabelecimentoId, $id);
 
            if (!$venda) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Venda não encontrada ou já finalizada.',
                ], 404);
            }
 
            // Valida a soma quando há pagamento dividido
            if (!empty($pagamentos)) {
                $soma = array_sum(array_column($pagamentos, 'valor'));
                if ($soma + 0.01 < (float) $venda['total']) {
                    return new JsonResponse([
                        'status' => 'error',
                        'mensagem' => 'A soma das formas (R$ ' . number_format($soma, 2, ',', '.')
                            . ') é menor que o total da venda (R$ ' . number_format((float) $venda['total'], 2, ',', '.') . ').',
                    ], 400);
                }
            }
 
            // ── Aplica crédito do cliente, quando solicitado e disponível ─
            $totalVenda = (float) $venda['total'];
            $valorCreditoAbatido = 0.0;
            $clienteIdVenda = null;

            if ($usarCreditoReq > 0 && $metodo !== 'pendente' && !empty($venda['pet_id'])) {
                $pet = $this->getRepositorio(Pet::class)->find((int) $venda['pet_id']);
                $clienteIdVenda = $pet && method_exists($pet, 'getDono_Id') ? $pet->getDono_Id() : null;

                if ($clienteIdVenda) {
                    $creditoRepo = $this->getRepositorio(\App\Entity\ClienteCreditoMovimento::class);
                    $saldo = $creditoRepo->saldoDoCliente($estabelecimentoId, (int) $clienteIdVenda);
                    $valorCreditoAbatido = min(round($usarCreditoReq, 2), round($saldo, 2), round($totalVenda, 2));

                    if ($valorCreditoAbatido > 0) {
                        $creditoRepo->inserir(
                            $estabelecimentoId,
                            (int) $clienteIdVenda,
                            isset($venda['pet_id']) ? (int) $venda['pet_id'] : null,
                            'saida',
                            $valorCreditoAbatido,
                            'Abatido na venda #' . $id . ' (PDV)',
                            'venda',
                            (int) $id,
                            null
                        );
                    }
                }
            }

            $totalEfetivo = round($totalVenda - $valorCreditoAbatido, 2);

            // Se o crédito cobriu tudo, não precisa gerar lançamento no financeiro.
            // Determina status final e registra no financeiro
            if ($metodo === 'pendente') {
                $statusFinal = 'Pendente';
                // Venda que já estava Pendente já tem o lançamento em financeiropendente:
                // não cria um segundo.
                if (($venda['status'] ?? null) !== 'Pendente' && $totalEfetivo > 0) {
                    $fpRepo->inserirPdv(
                        $estabelecimentoId,
                        $venda['cliente'] ?? 'Consumidor Final',
                        $totalEfetivo,
                        isset($venda['pet_id']) ? (int) $venda['pet_id'] : null,
                        $id
                    );
                }
            } else {
                $statusFinal = 'Paga';

                if (!empty($pagamentos)) {
                    // Pagamento dividido: a soma pode ser maior que o totalEfetivo
                    // (quando o crédito foi usado). Lança as formas pelo valor
                    // efetivo, proporcionalmente, para o financeiro não inflar.
                    $somaPagamentos = max(array_sum(array_column($pagamentos, 'valor')), 0.01);
                    foreach ($pagamentos as $p) {
                        $valorProporcional = $totalEfetivo > 0
                            ? round(((float) $p['valor'] / $somaPagamentos) * $totalEfetivo, 2)
                            : 0.0;
                        if ($valorProporcional > 0) {
                            $vendaRepo->inserirFinanceiro(
                                $estabelecimentoId,
                                $p['metodo'],
                                $valorProporcional,
                                $venda['cliente'] ?? 'Consumidor Final',
                                $venda['pet_id'] ?? null,
                                $id,
                                $dataVenda
                            );
                        }
                        $vendaRepo->inserirPagamento(
                            $estabelecimentoId,
                            $id,
                            $p['metodo'],
                            (float) $p['valor'],
                            $p['bandeira'],
                            $p['parcelas'],
                            $dataVenda
                        );
                    }
                } elseif ($totalEfetivo > 0) {
                    $vendaRepo->inserirFinanceiro(
                        $estabelecimentoId,
                        $metodo,
                        $totalEfetivo,
                        $venda['cliente'] ?? 'Consumidor Final',
                        $venda['pet_id'] ?? null,
                        $id,
                        $dataVenda
                    );
                }
            }
 
            // Atualiza a venda com SQL nativo — banco correto garantido
            $ok = $vendaRepo->finalizarVenda(
                $estabelecimentoId,
                $id,
                $metodo,
                $statusFinal,
                $bandeira,
                $parcelas,
                $dataVenda
            );
 
            if (!$ok) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Não foi possível atualizar a venda. Tente novamente.',
                ], 500);
            }
 
            // Troco como crédito: registra entrada quando o caixa escolhe
            // reservar o excedente ao invés de devolver em dinheiro.
            if ($deixarCreditoReq > 0 && $metodo === 'dinheiro' && !empty($venda['pet_id'])) {
                $pet = $pet ?? $this->getRepositorio(Pet::class)->find((int) $venda['pet_id']);
                $clienteIdVenda = $clienteIdVenda ?? ($pet && method_exists($pet, 'getDono_Id') ? $pet->getDono_Id() : null);

                if ($clienteIdVenda) {
                    $creditoRepo = $this->getRepositorio(\App\Entity\ClienteCreditoMovimento::class);
                    $creditoRepo->inserir(
                        $estabelecimentoId,
                        (int) $clienteIdVenda,
                        (int) $venda['pet_id'],
                        'entrada',
                        round($deixarCreditoReq, 2),
                        'Troco guardado como crédito na venda #' . $id,
                        'venda',
                        (int) $id,
                        null
                    );
                }
            }

            // Venda que estava PENDENTE e agora foi paga: o lançamento em
            // financeiropendente sai da lista de pendentes (o valor já entrou em
            // financeiro como 'Pago' acima).
            if ($metodo !== 'pendente' && ($venda['status'] ?? null) === 'Pendente') {
                $fpRepo->baixarPorVenda(
                    $estabelecimentoId,
                    $id,
                    (float) $venda['total'],
                    isset($venda['pet_id']) ? (int) $venda['pet_id'] : null
                );
            }

            // ── Emissão automática de NFS-e (Asaas) ──
            // (código mantido igual — não alterado)
            $notaFiscal = null;
 
            if ($metodo !== 'pendente' && $this->emissaoAutomaticaAtiva()) {
                $vendaEntity = $this->getRepositorio(Venda::class)->find($id);
                $this->restauraLoginDB();
 
                if ($vendaEntity && !empty($asaas->getConfig($estabelecimentoId)['api_key'])) {
                    try {
                        $resultadoNf = $asaas->emitir($vendaEntity);
                        $notaFiscal = [
                            'emitida' => true,
                            'asaas_invoice_id' => $resultadoNf['asaas_invoice_id'] ?? null,
                            'status' => $resultadoNf['status'] ?? null,
                        ];
                    } catch (NotaFiscalException | \Exception $e) {
                        $this->logger->error('Falha ao emitir NFS-e no fechamento do PDV.', [
                            'venda_id' => $id,
                            'erro' => $e->getMessage(),
                        ]);
                        $notaFiscal = ['emitida' => false, 'erro' => $e->getMessage()];
                    }
                }
            }
 
            return new JsonResponse([
                'status' => 'success',
                'mensagem' => 'Venda #' . $id . ' finalizada com sucesso!',
                'nota_fiscal' => $notaFiscal,
            ]);
 
        } catch (\Exception $e) {
            return new JsonResponse([
                'status' => 'error',
                'mensagem' => 'Erro ao finalizar venda: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Retorna os dados de uma venda em JSON para pré-carregar o PDV via popup (sem usar sessão).
     *
     * @Route("/dados-venda/{id}", name="pdv_dados_venda", methods={"GET"})
     */
    public function dadosVenda(int $id, EntityManagerInterface $em): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        $venda = $em->getRepository(Venda::class)->findOneBy([
            'id' => $id,
            'estabelecimentoId' => $estabelecimentoId,
        ]);

        if (!$venda) {
            return new JsonResponse(['ok' => false, 'msg' => 'Venda não encontrada.'], 404);
        }

        $nomeCliente = $venda->getCliente() ?? 'Consumidor Final';
        $petId = $venda->getPetId();
        $nomePet = null;

        if ($petId) {
            $pet = $em->getRepository(Pet::class)->find($petId);
            if ($pet) {
                $nomePet = $pet->getNome();
            }
        }

        $itensEntities = $em->getRepository(VendaItem::class)->findBy(['vendaId' => $venda->getId()]);
        $itensNormalizados = $this->normalizarItensDaVenda($em, $itensEntities);

        return new JsonResponse([
            'ok' => true,
            'venda_id' => $venda->getId(),
            'status' => $venda->getStatus(),
            'cliente_nome' => $nomeCliente,
            'pet_id' => $petId,
            'pet_nome' => $nomePet,
            'itens' => $itensNormalizados,
            'total' => $venda->getTotal(),
            'observacao' => $venda->getObservacao(),
        ]);
    }

    /**
     * Busca vendas de um pet
     *
     * @Route("/pet/{petId}/vendas", name="clinica_pdv_pet_vendas", methods={"GET"})
     */
    public function vendasPorPet(int $petId, EntityManagerInterface $em): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        try {
            // Busca pet
            $pet = $em->getRepository(Pet::class)
                ->findOneBy(['id' => $petId, 'estabelecimentoId' => $estabelecimentoId]);

            if (!$pet) {
                return new JsonResponse(['ok' => false, 'msg' => 'Pet não encontrado'], 404);
            }

            // Busca vendas do pet
            $vendas = $em->getRepository(Venda::class)
                ->findByPet($estabelecimentoId, $petId);

            $vendasFormatadas = [];
            $totalGasto = 0;

            foreach ($vendas as $venda) {
                $totalGasto += $venda->getTotal();

                $itens = $em->getRepository(VendaItem::class)
                    ->findBy(['vendaId' => $venda->getId()]);

                $itensFormatados = array_map(fn($item) => [
                    'produto' => $item->getProdutoNome(),
                    'quantidade' => $item->getQuantidade(),
                    'valor_unitario' => number_format($item->getValorUnitario(), 2, ',', '.'),
                    'subtotal' => number_format($item->getSubtotal(), 2, ',', '.'),
                ], $itens);

                $vendasFormatadas[] = [
                    'id' => $venda->getId(),
                    'data' => $venda->getData()->format('d/m/Y H:i'),
                    'total' => number_format($venda->getTotal(), 2, ',', '.'),
                    'metodo_pagamento' => $venda->getMetodoPagamento(),
                    'observacao' => $venda->getObservacao(),
                    'itens' => $itensFormatados,
                ];
            }

            return new JsonResponse([
                'ok' => true,
                'pet' => [
                    'id' => $pet->getId(),
                    'nome' => $pet->getNome(),
                    'especie' => $pet->getEspecie(),
                    'raca' => $pet->getRaca(),
                ],
                'vendas' => $vendasFormatadas,
                'resumo' => [
                    'total_vendas' => count($vendas),
                    'total_gasto' => number_format($totalGasto, 2, ',', '.'),
                    'ticket_medio' => count($vendas) > 0
                    ? number_format($totalGasto / count($vendas), 2, ',', '.')
                    : '0,00',
                ],
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'ok' => false,
                'msg' => 'Erro: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Resumo de vendas do dia
     *
     * @Route("/resumo-dia", name="clinica_pdv_resumo_dia", methods={"GET"})
     */
    public function resumoDia(Request $request): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $vendaRepo = $this->getRepositorio(Venda::class);

        try {
            $dataParam = $request->query->get('data');
            $data = $dataParam ? new \DateTime($dataParam) : new \DateTime();

            $resumo = $vendaRepo->getResumoDoDia($estabelecimentoId, $data);
            $porMetodo = $vendaRepo->totalPorFormaPagamento($estabelecimentoId, $data);

            return new JsonResponse([
                'ok' => true,
                'data' => $data->format('d/m/Y'),
                'resumo' => [
                    'quantidade_vendas' => $resumo['quantidade_vendas'],
                    'total_vendas' => number_format($resumo['total_vendas'], 2, ',', '.'),
                    'ticket_medio' => number_format($resumo['ticket_medio'], 2, ',', '.'),
                    'por_metodo' => $porMetodo,
                ],
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'ok' => false,
                'msg' => 'Erro: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Helpers privados
     */

    /**
     * Resolve o nome de exibição de um VendaItem.
     *
     * Itens gravados antes da refatoração tinham o ID numérico no campo
     * produtoNome (snapshot). Este método detecta esse caso e busca o nome
     * real no cadastro de Produtos ou Serviços, com fallback graceful.
     */
    /**
     * Liga/desliga a emissão automática de NFS-e no fechamento do PDV.
     *
     * Controlada pela variável de ambiente ASSAS_INIT:
     *   ASSAS_INIT=on   → emite automaticamente
     *   ASSAS_INIT=off  (ou ausente) → não emite
     * Aceita também 'true'/'1'/'enabled' como ligado.
     */
    private function emissaoAutomaticaAtiva(): bool
    {
        $flag = $_ENV['ASSAS_INIT'] ?? $_SERVER['ASSAS_INIT'] ?? 'off';

        return in_array(strtolower(trim((string) $flag)), ['on', 'true', '1', 'enabled'], true);
    }

    /**
     * Resolve o ID numérico de um VendaItem garantindo que nunca seja null/zero.
     *
     * Itens legados podem ter produtoId=null e o ID numérico guardado
     * no snapshot do nome (campo produto). Este método normaliza os dois casos.
     */
    private function resolverProdutoId(VendaItem $item): int
    {
        if ($item->getProdutoId()) {
            return $item->getProdutoId();
        }

        // Fallback: snapshot numérico (dado legado)
        $snapshot = $item->getProduto();
        if ($snapshot !== null && is_numeric(trim($snapshot))) {
            return (int) trim($snapshot);
        }

        // Sem ID válido — retorna 0 (tratado no EstoqueService)
        return 0;
    }

    /**
     * Converte os VendaItem de uma venda no payload que o carrinho do PDV lê.
     *
     * ── Por que o id leva o sufixo "#<id do venda_item>" ─────────────────────
     * O carrinho do PDV identifica cada linha pelo campo `id` ('serv_12').
     * Numa venda de atendimento com 2+ pets, o MESMO serviço aparece uma vez
     * por pet (coleta de sangue do Rex + coleta de sangue da Mel) — duas linhas
     * de venda_item com o mesmo produto_id. Com o id repetido, o JS tratava as
     * duas como a mesma linha: remover uma apagava as duas e alterar a
     * quantidade só pegava a primeira, e o total do caixa saía diferente do
     * total lançado na ficha.
     *
     * O sufixo torna cada linha única sem quebrar quem extrai o id numérico —
     * PdvService::extrairIdNumerico() e EstoqueService::extrairProdutoId()
     * fazem cast para int, e 'serv_12#48' → '12#48' → 12.
     *
     * ── Por que o unitário é o efetivo ───────────────────────────────────────
     * O carrinho recalcula subtotal = quantidade × unitário; ele não tem
     * desconto por linha. Repassando o unitário cheio, uma venda lançada com
     * desconto na ficha aparecia no caixa por um valor maior que o da venda.
     * Repassamos o unitário já líquido para o carrinho fechar no mesmo total,
     * mantendo o valor de tabela em `valor_unitario_bruto` para exibição.
     *
     * @param VendaItem[] $itens
     * @return array<int, array<string, mixed>>
     */
    private function normalizarItensDaVenda(EntityManagerInterface $em, array $itens): array
    {
        $normalizados = [];

        foreach ($itens as $item) {
            $tipo = $item->getTipo(); // já normalizado para lowercase na entity
            $produtoId = $this->resolverProdutoId($item); // trata legado com produtoId null

            $idFrontend = ($tipo === 'produto' ? 'prod_' : 'serv_') . $produtoId;

            if ($item->getId()) {
                $idFrontend .= '#' . $item->getId();
            }

            $quantidade = max(1, (int) $item->getQuantidade());
            $unitario   = (float) $item->getValorUnitario();
            $subtotal   = (float) $item->getSubtotal();
            $desconto   = round(($unitario * $quantidade) - $subtotal, 2);

            $normalizados[] = [
                'id' => $idFrontend,
                'nome' => $this->resolverNomeItem($em, $item),
                'tipo' => ucfirst($tipo),
                'quantidade' => $quantidade,
                'valor_unitario' => $desconto > 0 ? round($subtotal / $quantidade, 2) : $unitario,
                'valor_unitario_bruto' => $unitario,
                'desconto' => max(0.0, $desconto),
                'subtotal' => $subtotal,
            ];
        }

        return $normalizados;
    }

    private function resolverNomeItem(EntityManagerInterface $em, VendaItem $item): string
    {
        $snapshot = $item->getProdutoNome();
        $produtoId = $item->getProdutoId();

        // Se o snapshot não é numérico, é um nome válido — retorna direto
        if ($snapshot !== null && !is_numeric(trim($snapshot))) {
            return $snapshot;
        }

        // Snapshot é numérico (dado legado) ou nulo — busca no cadastro pelo produtoId
        $idBusca = $produtoId ?? (int) trim((string) $snapshot);

        if (!$idBusca) {
            return $snapshot ?? 'Item sem descrição';
        }

        if ($item->getTipo() === 'produto') {
            $entidade = $em->getRepository(Produto::class)->find($idBusca);
        } else {
            $entidade = $em->getRepository(Servico::class)->find($idBusca);
        }

        return $entidade ? $entidade->getNome() : ($snapshot ?? "Item #{$idBusca}");
    }

    private function normalizarItens(array $produtos, array $servicos): array
    {
        $itens = [];

        foreach ($produtos as $p) {
            $itens[] = [
                "id" => "prod_" . $p->getId(),
                "nome" => $p->getNome(),
                "valor" => $p->getPrecoVenda() ?? 0.0,
                "estoque" => $p->getEstoqueAtual() ?? 0,
                "tipo" => "Produto",
                "descricao" => $p->getNome() ?? "",
            ];
        }

        foreach ($servicos as $s) {
            $itens[] = [
                "id" => "serv_" . $s->getId(),
                "nome" => $s->getNome(),
                "valor" => $s->getValor() ?? 0.0,
                "estoque" => null,
                "tipo" => "Serviço",
                "descricao" => $s->getDescricao() ?? "",
            ];
        }

        usort($itens, fn($a, $b) => strcmp($a["nome"], $b["nome"]));

        return $itens;
    }

    private function buscarItensVenda(EntityManagerInterface $em, int $vendaId): array
    {
        $itens = $em->getRepository(VendaItem::class)->findBy(['vendaId' => $vendaId]);

        return array_map(fn($item) => [
            'descricao' => $this->resolverNomeItem($em, $item),
            'quantidade' => $item->getQuantidade(),
            'valor_unitario' => $item->getValorUnitario(),
            'subtotal' => $item->getSubtotal(),
        ], $itens);
    }
}