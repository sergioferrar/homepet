<?php

namespace App\Controller;

use App\DTO\RegistrarSaidaDTO;
use App\DTO\RegistrarVendaDTO;
use App\Entity\Cliente;
use App\Entity\FinanceiroPendente;
use App\Entity\Pet;
use App\Entity\Produto;
use App\Entity\Servico;
use App\Entity\Venda;
use App\Entity\VendaItem;
use App\Service\CaixaService;
use App\Service\DataVendaRetroativa;
use App\Service\NotaFiscal\AsaasNotaFiscalService;
use App\Service\NotaFiscal\NotaFiscalException;
use App\Service\PdvService;
use App\Service\TenantContext;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Controller do PDV - Apenas coordena requests, toda lógica está nos Services
 *
 * @Route("dashboard/clinica/pdv")
 */
class PdvController extends DefaultController
{

    /**
     * Tela principal do PDV
     *
     * @Route("", name="clinica_pdv_index", methods={"GET"})
     */
    public function index(EntityManagerInterface $em, Request $request): Response
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $conn = $em->getConnection();

        // ── Produtos + serviços numa consulta cada, só com as colunas usadas
        // pelo front. Evita hidratar milhares de entidades. ───────────────
        $produtosRows = $conn->fetchAllAssociative(
            "SELECT id, nome, preco_venda AS valor, estoque_atual AS estoque
             FROM homepet_{$estabelecimentoId}.produto
             WHERE estabelecimento_id = :estab",
            ['estab' => $estabelecimentoId]
        );

        $servicosRows = $conn->fetchAllAssociative(
            "SELECT id, nome, valor, descricao
             FROM homepet_{$estabelecimentoId}.servico
             WHERE estabelecimento_id = :estab",
            ['estab' => $estabelecimentoId]
        );

        $itensNormalizados = [];
        foreach ($produtosRows as $p) {
            $itensNormalizados[] = [
                'id' => 'prod_' . $p['id'],
                'nome' => $p['nome'],
                'valor' => (float) ($p['valor'] ?? 0),
                'estoque' => $p['estoque'] !== null ? (int) $p['estoque'] : 0,
                'tipo' => 'Produto',
                'descricao' => $p['nome'] ?? '',
            ];
        }
        foreach ($servicosRows as $s) {
            $itensNormalizados[] = [
                'id' => 'serv_' . $s['id'],
                'nome' => $s['nome'],
                'valor' => (float) ($s['valor'] ?? 0),
                'estoque' => null,
                'tipo' => 'Serviço',
                'descricao' => $s['descricao'] ?? '',
            ];
        }
        usort($itensNormalizados, fn($a, $b) => strcmp((string) $a['nome'], (string) $b['nome']));

        // Clientes: apenas colunas realmente exibidas no autocomplete.
        $clientesNormalizados = $conn->fetchAllAssociative(
            "SELECT id, nome, email, telefone
             FROM homepet_{$estabelecimentoId}.cliente
             WHERE estabelecimento_id = :estab
             ORDER BY nome",
            ['estab' => $estabelecimentoId]
        );

        // Vendas em carrinho
        $vendasCarrinho = $em->getRepository(Venda::class)
            ->findCarrinho($estabelecimentoId);

        // Lê (e consome) o payload da venda pré-carregada gravado por carregarVendaNopdv()
        $session = $request->getSession();
        $vendaPreCarregada = $session->get('pdv_venda_pre_carregada');
        if ($vendaPreCarregada !== null) {
            $session->remove('pdv_venda_pre_carregada');
        }

        return $this->render("clinica/pdv.html.twig", [
            'produtos' => $itensNormalizados,
            'clientes' => $clientesNormalizados,
            'vendas_carrinho' => $vendasCarrinho ?? [],
            'vendaPreCarregada' => $vendaPreCarregada, // null quando não há pré-carregamento
        ]);
    }

    /**
     * Carrega uma venda da clínica no PDV (Lançar no Caixa)
     *
     * @Route("/carregar/{id}", name="pdv_carregar", methods={"GET"})
     */
    public function carregarVendaNopdv(
        int $id,
        EntityManagerInterface $em,
        Request $request
    ): Response {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        $session = $request->getSession();

        // 1. Busca a venda garantindo que pertence ao estabelecimento
        $venda = $em->getRepository(Venda::class)->findOneBy([
            'id' => $id,
            'estabelecimentoId' => $estabelecimentoId,
        ]);

        if (!$venda) {
            $this->addFlash('danger', 'Venda não encontrada.');
            return $this->redirectToRoute('clinica_pdv_listar');
        }

        // 2. Valida status — só carrega vendas abertas / em carrinho
        $statusPermitidos = ['Aberta', 'Carrinho', 'carrinho', 'Pendente'];
        if (!in_array($venda->getStatus(), $statusPermitidos, true)) {
            $this->addFlash('warning', sprintf(
                'A venda #%d não pode ser lançada no caixa (status: %s).',
                $venda->getId(),
                $venda->getStatus()
            ));
            return $this->redirectToRoute('clinica_pdv_listar');
        }

        // 3. Busca os itens da venda
        $itensEntities = $em->getRepository(VendaItem::class)->findBy(['vendaId' => $venda->getId()]);

        // 4. Monta payload de itens para a sessão
        $itensNormalizados = $this->normalizarItensDaVenda($em, $itensEntities);

        // Se o total gravado for menor que a soma dos subtotais, significa que
        // um crédito foi aplicado antes. Mantém a diferença como desconto para
        // o PDV não cobrar o valor cheio.
        $somaSubtotais = array_sum(array_column($itensNormalizados, 'subtotal'));
        $descontoCredito = max(0.0, round($somaSubtotais - (float) $venda->getTotal(), 2));

        // 5. Resolve nome do cliente e pet (e localiza o cliente_id para crédito)
        $nomeCliente = $venda->getCliente() ?? 'Consumidor Final';
        $petId = $venda->getPetId();
        $nomePet = null;
        $clienteId = null;
        $creditoDisponivel = 0.0;

        if ($petId) {
            $pet = $em->getRepository(Pet::class)->find($petId);
            if ($pet) {
                $nomePet = $pet->getNome();
                $clienteId = method_exists($pet, 'getDono_Id') ? $pet->getDono_Id() : null;
            }
        }

        if ($clienteId) {
            $creditoDisponivel = $this->getRepositorio(\App\Entity\ClienteCreditoMovimento::class)
                ->saldoDoCliente($estabelecimentoId, (int) $clienteId);
        }

        // 6. Grava tudo na sessão — o PDV lê via Twig/JS
        $session->set('pdv_venda_pre_carregada', [
            'venda_id' => $venda->getId(),
            'cliente_nome' => $nomeCliente,
            'cliente_id' => $clienteId,
            'pet_id' => $petId,
            'pet_nome' => $nomePet,
            'itens' => $itensNormalizados,
            'total' => $venda->getTotal(),
            'observacao' => $venda->getObservacao(),
            'credito_disponivel' => round($creditoDisponivel, 2),
            'desconto_credito' => $descontoCredito,
        ]);

        $this->addFlash('success', sprintf(
            'Venda #%d carregada no PDV. Revise os itens e finalize.',
            $venda->getId()
        ));
        
        $dataRequest = [];
        $dataRequest['vendaId'] = $venda->getId();

        if($request->get('ficha')){
            $dataRequest['ficha'] = true;
        }
        // 7. Redireciona para a tela principal do PDV
        return $this->redirectToRoute('clinica_pdv_index', $dataRequest);
    }

    /**
     * Lê os ids de vendas da querystring (ids=1,2,3 ou ids[]=1&ids[]=2).
     *
     * @return int[]
     */
    private function extrairIdsDaRequisicao(Request $request): array
    {
        $bruto = $request->query->all()['ids'] ?? [];
        if (is_string($bruto)) {
            $bruto = explode(',', $bruto);
        }

        return array_values(array_unique(array_filter(
            array_map('intval', (array) $bruto),
            static fn (int $i): bool => $i > 0
        )));
    }

    /**
     * Monta o payload do PDV para uma ou várias vendas da clínica (itens
     * agrupados, total somado, crédito do cliente etc.).
     *
     * Usado tanto pelo carregamento com redirect (sessão) quanto pelo JSON
     * consumido pelo offcanvas do PDV.
     *
     * @param int[] $ids
     * @return array{ok:bool, http:int, mensagem:string, payload:?array}
     */
    private function montarPayloadVendasEmLote(EntityManagerInterface $em, int $estabelecimentoId, array $ids): array
    {
        $falha = static fn (string $mensagem, int $http = 400): array => [
            'ok' => false, 'http' => $http, 'mensagem' => $mensagem, 'payload' => null,
        ];

        if (count($ids) === 0) {
            return $falha('Selecione ao menos uma venda para lançar no caixa.');
        }

        if (count($ids) > 50) {
            return $falha('Selecione no máximo 50 vendas por vez.');
        }

        // Mesmos status que pdv_finalizar_carrinho aceita
        $statusPermitidos = ['Aberta', 'Pendente'];

        $vendas = [];
        foreach ($ids as $id) {
            $venda = $em->getRepository(Venda::class)->findOneBy([
                'id' => $id,
                'estabelecimentoId' => $estabelecimentoId,
            ]);

            if (!$venda) {
                return $falha(sprintf('Venda #%d não encontrada. Nada foi carregado.', $id), 404);
            }

            if (!in_array($venda->getStatus(), $statusPermitidos, true)) {
                return $falha(sprintf(
                    'A venda #%d não pode ser lançada no caixa (status: %s). Nada foi carregado.',
                    $venda->getId(),
                    $venda->getStatus()
                ), 409);
            }

            $vendas[] = $venda;
        }

        // Todas precisam ser do mesmo cliente e do mesmo pet
        $petId = $vendas[0]->getPetId() ? (int) $vendas[0]->getPetId() : null;
        $nomeCliente = $vendas[0]->getCliente() ?? 'Consumidor Final';
        $chaveCliente = mb_strtolower(trim((string) $nomeCliente));

        foreach ($vendas as $venda) {
            $petDaVenda = $venda->getPetId() ? (int) $venda->getPetId() : null;
            $clienteDaVenda = mb_strtolower(trim((string) ($venda->getCliente() ?? 'Consumidor Final')));

            if ($petDaVenda !== $petId || $clienteDaVenda !== $chaveCliente) {
                return $falha('Só é possível agrupar vendas do mesmo cliente e do mesmo pet. Nada foi carregado.');
            }
        }

        // Junta os itens de todas as vendas
        $todosItens = [];
        $totalGeral = 0.0;
        $descontoCredito = 0.0;
        $observacoes = [];

        foreach ($vendas as $venda) {
            $itensEntities = $em->getRepository(VendaItem::class)->findBy(['vendaId' => $venda->getId()]);
            $itensVenda = $this->normalizarItensDaVenda($em, $itensEntities);

            // Crédito abatido antes (mesma regra do carregamento individual)
            $somaSubtotais = array_sum(array_column($itensVenda, 'subtotal'));
            $descontoCredito += max(0.0, round($somaSubtotais - (float) $venda->getTotal(), 2));

            $totalGeral += (float) $venda->getTotal();
            array_push($todosItens, ...$itensVenda);

            $obs = trim((string) $venda->getObservacao());
            if ($obs !== '' && !in_array($obs, $observacoes, true)) {
                $observacoes[] = $obs;
            }
        }

        // Agrupa linhas idênticas (mesmo tipo, nome e valor unitário) somando as quantidades
        $agrupados = [];
        foreach ($todosItens as $item) {
            $chave = $item['tipo'] . '|' . $item['nome'] . '|' . number_format((float) $item['valor_unitario'], 2, '.', '');

            if (!isset($agrupados[$chave])) {
                $agrupados[$chave] = $item;
                continue;
            }

            $agrupados[$chave]['quantidade'] += $item['quantidade'];
            $agrupados[$chave]['subtotal'] = round($agrupados[$chave]['subtotal'] + $item['subtotal'], 2);
            $agrupados[$chave]['desconto'] = round($agrupados[$chave]['desconto'] + $item['desconto'], 2);
        }
        $itensAgrupados = array_values($agrupados);

        // Pet e crédito do cliente (mesma lógica do carregamento individual)
        $nomePet = null;
        $clienteId = null;
        $creditoDisponivel = 0.0;

        if ($petId) {
            $pet = $em->getRepository(Pet::class)->find($petId);
            if ($pet) {
                $nomePet = $pet->getNome();
                $clienteId = method_exists($pet, 'getDono_Id') ? $pet->getDono_Id() : null;
            }
        }

        if ($clienteId) {
            $creditoDisponivel = $this->getRepositorio(\App\Entity\ClienteCreditoMovimento::class)
                ->saldoDoCliente($estabelecimentoId, (int) $clienteId);
        }

        $idsVendas = array_map(static fn (Venda $v): int => (int) $v->getId(), $vendas);

        return [
            'ok' => true,
            'http' => 200,
            'mensagem' => '',
            'payload' => [
                // venda_id (a primeira) mantém compatível tudo que já lê esse campo no PDV
                'venda_id' => $idsVendas[0],
                'venda_ids' => $idsVendas,
                'cliente_nome' => $nomeCliente,
                'cliente_id' => $clienteId,
                'pet_id' => $petId,
                'pet_nome' => $nomePet,
                'itens' => $itensAgrupados,
                'total' => round($totalGeral, 2),
                'observacao' => $observacoes ? implode(' | ', $observacoes) : null,
                'credito_disponivel' => round($creditoDisponivel, 2),
                'desconto_credito' => round($descontoCredito, 2),
            ],
        ];
    }

    /**
     * Carrega VÁRIAS vendas da clínica no PDV de uma só vez (agrupadas),
     * gravando na sessão e redirecionando para o PDV.
     *
     * @Route("/carregar-lote", name="pdv_carregar_lote", methods={"GET"})
     */
    public function carregarVendasEmLote(
        EntityManagerInterface $em,
        Request $request
    ): Response {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        $ids = $this->extrairIdsDaRequisicao($request);
        $paramsListar = $request->get('ficha') ? ['ficha' => true] : [];

        // Uma venda só: segue o fluxo de sempre
        if (count($ids) === 1) {
            return $this->redirectToRoute('pdv_carregar', ['id' => $ids[0]] + $paramsListar);
        }

        $resultado = $this->montarPayloadVendasEmLote($em, $estabelecimentoId, $ids);

        if (!$resultado['ok']) {
            $this->addFlash('warning', $resultado['mensagem']);
            return $this->redirectToRoute('clinica_pdv_listar', $paramsListar);
        }

        $payload = $resultado['payload'];
        $request->getSession()->set('pdv_venda_pre_carregada', $payload);

        $this->addFlash('success', sprintf(
            '%d vendas agrupadas no PDV (%s). Revise os itens e finalize.',
            count($payload['venda_ids']),
            '#' . implode(', #', $payload['venda_ids'])
        ));

        $dataRequest = ['vendaId' => $payload['venda_id']];
        if ($request->get('ficha')) {
            $dataRequest['ficha'] = true;
        }

        return $this->redirectToRoute('clinica_pdv_index', $dataRequest);
    }

    /**
     * Mesmo carregamento agrupado, mas em JSON — usado pelo offcanvas do PDV
     * para trazer as vendas ao carrinho sem recarregar a página.
     *
     * @Route("/carregar-lote-json", name="pdv_carregar_lote_json", methods={"GET"})
     */
    public function carregarVendasEmLoteJson(
        EntityManagerInterface $em,
        Request $request
    ): JsonResponse {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        $resultado = $this->montarPayloadVendasEmLote(
            $em,
            $estabelecimentoId,
            $this->extrairIdsDaRequisicao($request)
        );

        if (!$resultado['ok']) {
            return new JsonResponse(['ok' => false, 'mensagem' => $resultado['mensagem']], $resultado['http']);
        }

        return new JsonResponse(['ok' => true, 'payload' => $resultado['payload']]);
    }

    /**
     * Listagem de vendas em JSON para o offcanvas do PDV.
     *
     * modo=abertas (padrão): só vendas que podem ser lançadas (Aberta/Pendente), sem limite de data.
     * modo=todas: todas as vendas dos últimos `dias` dias (1 a 365, padrão 30).
     * Devolve no máximo 500 vendas (campo `truncado` avisa quando passou disso).
     *
     * @Route("/listar-json", name="clinica_pdv_listar_json", methods={"GET"})
     */
    public function listarVendasJson(EntityManagerInterface $em, Request $request): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $conn = $em->getConnection();

        $modo = $request->query->get('modo') === 'todas' ? 'todas' : 'abertas';
        $dias = max(1, min(365, (int) $request->query->get('dias', 30)));
        $limite = 500;

        $params = ['estab' => $estabelecimentoId];
        if ($modo === 'abertas') {
            $filtro = "AND v.status IN ('Aberta', 'Pendente')";
        } else {
            $filtro = 'AND v.data >= :desde';
            $params['desde'] = (new \DateTime('today'))->modify('-' . ($dias - 1) . ' days')->format('Y-m-d 00:00:00');
        }

        $sql = "SELECT v.id,
                       v.data,
                       v.cliente,
                       v.total,
                       v.metodo_pagamento AS metodo,
                       v.status,
                       v.pet_id AS petId,
                       p.nome AS petNome
                FROM homepet_{$estabelecimentoId}.venda v
                LEFT JOIN homepet_{$estabelecimentoId}.pet p ON p.id = v.pet_id
                WHERE v.estabelecimento_id = :estab
                  {$filtro}
                ORDER BY v.data DESC, v.id DESC
                LIMIT " . ($limite + 1);

        $linhas = $conn->fetchAllAssociative($sql, $params);

        $truncado = count($linhas) > $limite;
        if ($truncado) {
            $linhas = array_slice($linhas, 0, $limite);
        }

        // Itens de todas as vendas numa única consulta (sem N+1)
        $itensPorVenda = [];
        if ($linhas) {
            $ids = array_map(static fn (array $l): int => (int) $l['id'], $linhas);
            $marcadores = implode(',', array_fill(0, count($ids), '?'));
            $itens = $conn->fetchAllAssociative(
                "SELECT venda_id, produto, quantidade
                 FROM homepet_{$estabelecimentoId}.venda_item
                 WHERE venda_id IN ({$marcadores})
                 ORDER BY id",
                $ids
            );

            foreach ($itens as $item) {
                $nome = trim((string) $item['produto']);
                // Dado legado: o snapshot era só o id do cadastro
                if ($nome === '' || is_numeric($nome)) {
                    $nome = 'Item';
                }
                $qtd = max(1, (int) $item['quantidade']);
                $itensPorVenda[(int) $item['venda_id']][] = ($qtd > 1 ? $qtd . '× ' : '') . $nome;
            }
        }

        $statusSelecionaveis = ['Aberta', 'Pendente'];
        $vendas = [];
        foreach ($linhas as $l) {
            $id = (int) $l['id'];
            $itensDaVenda = $itensPorVenda[$id] ?? [];

            $vendas[] = [
                'id' => $id,
                'data' => $l['data'] ? (new \DateTime($l['data']))->format(\DateTime::ATOM) : null,
                'cliente' => $l['cliente'] ?: 'Consumidor Final',
                'pet_id' => $l['petId'] ? (int) $l['petId'] : null,
                'pet_nome' => $l['petNome'],
                'total' => (float) $l['total'],
                'status' => $l['status'],
                'metodo' => $l['metodo'],
                'selecionavel' => in_array($l['status'], $statusSelecionaveis, true),
                'itens_qtd' => count($itensDaVenda),
                'itens' => array_slice($itensDaVenda, 0, 3),
            ];
        }

        return new JsonResponse([
            'ok' => true,
            'modo' => $modo,
            'dias' => $dias,
            'limite' => $limite,
            'truncado' => $truncado,
            'vendas' => $vendas,
        ]);
    }

    /**
     * Finaliza várias vendas de uma vez, com um único pagamento (PDV agrupado).
     *
     * Reaproveita finalizarCarrinho() para cada venda, então financeiro,
     * pagamentos, crédito, baixa de pendentes e NFS-e seguem exatamente as
     * mesmas regras da finalização individual. Antes de começar, tudo é
     * validado: se algo estiver errado, nenhuma venda é alterada.
     *
     * @Route("/carrinho/finalizar-lote", name="pdv_finalizar_lote", methods={"POST"})
     */
    public function finalizarLote(
        Request $request,
        AsaasNotaFiscalService $asaas
    ): JsonResponse {
        $this->switchDB();
        $vendaRepo = $this->getRepositorio(Venda::class);

        try {
            $contentType = $request->headers->get('Content-Type', '');
            $dados = str_contains($contentType, 'application/json')
                ? (json_decode($request->getContent(), true) ?? [])
                : $request->request->all();

            $ids = array_values(array_unique(array_filter(
                array_map('intval', (array) ($dados['ids'] ?? [])),
                static fn (int $i): bool => $i > 0
            )));

            if (count($ids) === 0 || count($ids) > 50) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Informe de 1 a 50 vendas para finalizar.',
                ], 400);
            }

            $metodo = $dados['metodo_pagamento'] ?? '';
            $bandeira = $dados['bandeira_cartao'] ?? null;
            $parcelas = !empty($dados['parcelas']) ? (int) $dados['parcelas'] : null;
            $usarCredito = isset($dados['usar_credito'])
                ? (float) str_replace(',', '.', (string) $dados['usar_credito'])
                : 0.0;
            $deixarCredito = isset($dados['deixar_credito'])
                ? (float) str_replace(',', '.', (string) $dados['deixar_credito'])
                : 0.0;
            // Pagamento parcial: o que faltar vira débito do cliente
            $fiado = !empty($dados['fiado']);

            // Pagamento dividido (opcional) — mesma normalização de finalizarCarrinho()
            $pagamentos = [];
            foreach ($dados['pagamentos'] ?? [] as $p) {
                $m = trim((string) ($p['metodo'] ?? ''));
                $v = (float) ($p['valor'] ?? 0);
                if ($m === '' || $v <= 0) {
                    continue;
                }
                $pagamentos[] = [
                    'metodo'   => $m,
                    'valor'    => round($v, 2),
                    'bandeira' => !empty($p['bandeira']) ? (string) $p['bandeira'] : null,
                    'parcelas' => !empty($p['parcelas']) ? (int) $p['parcelas'] : null,
                ];
            }

            foreach ($pagamentos as $p) {
                if ($p['metodo'] === 'pendente') {
                    return new JsonResponse([
                        'status' => 'error',
                        'mensagem' => 'Pagamento dividido não pode incluir a forma "Pendente".',
                    ], 400);
                }
            }

            if (empty($pagamentos) && empty($metodo)) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Método de pagamento não informado.',
                ], 400);
            }

            if (empty($pagamentos)) {
                $fiado = false; // sem formas informadas o pagamento é integral
            }

            if ($fiado && $usarCredito > 0) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Não dá para combinar o crédito do cliente com débito (pagamento parcial) na mesma baixa. Desmarque uma das opções.',
                ], 400);
            }

            // Valida a data antes de mexer em qualquer venda
            $dataVendaStr = is_string($dados['data_venda'] ?? null) ? $dados['data_venda'] : null;
            try {
                DataVendaRetroativa::resolver($dataVendaStr);
            } catch (\InvalidArgumentException $e) {
                return new JsonResponse(['status' => 'error', 'mensagem' => $e->getMessage()], 400);
            }

            $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

            // Todas as vendas precisam existir e estar abertas/pendentes
            $vendas = [];
            foreach ($ids as $id) {
                $venda = $vendaRepo->findVendaCarrinho($estabelecimentoId, $id);
                if (!$venda) {
                    return new JsonResponse([
                        'status' => 'error',
                        'mensagem' => 'Venda #' . $id . ' não encontrada ou já finalizada. Nenhuma venda foi alterada.',
                    ], 404);
                }
                $vendas[$id] = $venda;
            }

            // Mesmo cliente e mesmo pet
            $primeira = reset($vendas);
            $petRef = !empty($primeira['pet_id']) ? (int) $primeira['pet_id'] : null;
            $clienteRef = mb_strtolower(trim((string) ($primeira['cliente'] ?? '')));
            foreach ($vendas as $venda) {
                $petVenda = !empty($venda['pet_id']) ? (int) $venda['pet_id'] : null;
                $clienteVenda = mb_strtolower(trim((string) ($venda['cliente'] ?? '')));
                if ($petVenda !== $petRef || $clienteVenda !== $clienteRef) {
                    return new JsonResponse([
                        'status' => 'error',
                        'mensagem' => 'As vendas precisam ser do mesmo cliente e do mesmo pet. Nenhuma venda foi alterada.',
                    ], 400);
                }
            }

            if ($fiado && !$petRef) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Para deixar o restante como débito, as vendas precisam ter um pet/cliente vinculado. Nenhuma venda foi alterada.',
                ], 400);
            }

            $totais = [];
            foreach ($vendas as $id => $venda) {
                $totais[$id] = (float) $venda['total'];
            }
            $totalGrupo = array_sum($totais);

            if (!empty($pagamentos) && !$fiado) {
                $soma = array_sum(array_column($pagamentos, 'valor'));
                // Compara em centavos para não depender de arredondamento de float
                if ((int) round($soma * 100) < (int) round($totalGrupo * 100)) {
                    return new JsonResponse([
                        'status' => 'error',
                        'mensagem' => 'A soma das formas (R$ ' . number_format($soma, 2, ',', '.')
                            . ') é menor que o total das vendas (R$ ' . number_format($totalGrupo, 2, ',', '.') . ').',
                    ], 400);
                }
            }

            $pagamentosPorVenda = !empty($pagamentos)
                ? $this->ratearPagamentosEntreVendas($pagamentos, $totais)
                : [];

            // Finaliza uma a uma, reaproveitando a lógica existente
            $finalizadas = [];
            $falhas = [];
            $avisos = [];
            $saldoDevedorTotal = 0.0;
            $restanteCredito = max(0.0, round($usarCredito, 2));
            $ultimoId = array_key_last($totais);

            foreach ($totais as $id => $totalVenda) {
                $creditoDestaVenda = min($restanteCredito, $totalVenda);
                $restanteCredito = round($restanteCredito - $creditoDestaVenda, 2);

                $alocados = $pagamentosPorVenda[$id] ?? [];
                $somaAlocada = array_sum(array_column($alocados, 'valor'));

                $payload = [
                    'metodo_pagamento' => $metodo,
                    'bandeira_cartao'  => $bandeira,
                    'parcelas'         => $parcelas,
                    'pagamentos'       => $alocados,
                    'data_venda'       => $dataVendaStr,
                    'usar_credito'     => $creditoDestaVenda,
                    // o troco guardado como crédito entra uma única vez, na última venda
                    'deixar_credito'   => $id === $ultimoId ? $deixarCredito : 0,
                    // a venda que ficou só parcialmente coberta guarda o saldo como débito
                    'fiado'            => $fiado && $somaAlocada > 0 && ($somaAlocada + 0.005) < $totalVenda,
                ];

                // Pagamento parcial: venda que não recebeu nada do que foi pago agora segue o
                // fluxo normal de "Pendente" (o total inteiro fica no financeiro pendente).
                if ($fiado && $somaAlocada <= 0) {
                    $payload['metodo_pagamento'] = 'pendente';
                    $payload['pagamentos'] = [];
                    $payload['usar_credito'] = 0;
                    $payload['deixar_credito'] = 0;
                    $saldoDevedorTotal += $totalVenda;
                }

                $subRequest = new Request([], [], [], [], [], ['CONTENT_TYPE' => 'application/json'], json_encode($payload));
                $resposta = $this->finalizarCarrinho($subRequest, (int) $id, $asaas);
                $corpo = json_decode($resposta->getContent(), true) ?: [];

                if (($corpo['status'] ?? null) === 'success') {
                    $finalizadas[] = (int) $id;
                    $saldoDevedorTotal += (float) ($corpo['saldo_devedor'] ?? 0);

                    if (isset($corpo['nota_fiscal']['emitida']) && $corpo['nota_fiscal']['emitida'] === false) {
                        $avisos[] = 'NFS-e da venda #' . $id . ' não foi emitida: ' . ($corpo['nota_fiscal']['erro'] ?? 'erro desconhecido');
                    }
                    continue;
                }

                $falhas[] = [
                    'id' => (int) $id,
                    'mensagem' => $corpo['mensagem'] ?? 'Erro ao finalizar a venda.',
                ];
                $this->logger->error('Falha ao finalizar venda em lote no PDV.', [
                    'venda_id' => $id,
                    'lote' => array_keys($totais),
                    'erro' => $corpo['mensagem'] ?? null,
                ]);
                break; // para na primeira falha; as demais continuam abertas
            }

            if (empty($falhas)) {
                return new JsonResponse([
                    'status' => 'success',
                    'mensagem' => count($finalizadas) . ' vendas finalizadas com sucesso!'
                        . ($saldoDevedorTotal > 0.01 ? ' Débito de R$ ' . number_format($saldoDevedorTotal, 2, ',', '.') . ' lançado para o cliente.' : ''),
                    'finalizadas' => $finalizadas,
                    'saldo_devedor' => round($saldoDevedorTotal, 2),
                    'avisos' => $avisos,
                ]);
            }

            $pendentesDeFinalizar = array_values(array_diff(array_keys($totais), $finalizadas));

            return new JsonResponse([
                'status' => empty($finalizadas) ? 'error' : 'partial',
                'mensagem' => empty($finalizadas)
                    ? 'Não foi possível finalizar as vendas: ' . $falhas[0]['mensagem']
                    : 'Foram finalizadas as vendas #' . implode(', #', $finalizadas)
                        . '. A venda #' . $falhas[0]['id'] . ' falhou (' . $falhas[0]['mensagem'] . ')'
                        . ' e as vendas #' . implode(', #', array_diff($pendentesDeFinalizar, [$falhas[0]['id']]) ?: ['—'])
                        . ' continuam abertas. Selecione-as novamente na listagem.',
                'finalizadas' => $finalizadas,
                'falhas' => $falhas,
                'avisos' => $avisos,
            ], empty($finalizadas) ? 500 : 200);

        } catch (\Exception $e) {
            return new JsonResponse([
                'status' => 'error',
                'mensagem' => 'Erro ao finalizar vendas: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Distribui as formas de pagamento informadas entre as vendas do lote,
     * preenchendo uma venda por vez (em centavos, sem perder nem criar valor).
     * Qualquer excedente (ex.: dinheiro acima do total) vai para a última venda.
     *
     * @param array<int, array{metodo:string, valor:float, bandeira:?string, parcelas:?int}> $pagamentos
     * @param array<int, float> $totais id da venda => total
     * @return array<int, array<int, array{metodo:string, valor:float, bandeira:?string, parcelas:?int}>>
     */
    private function ratearPagamentosEntreVendas(array $pagamentos, array $totais): array
    {
        $restante = [];
        foreach ($pagamentos as $i => $p) {
            $restante[$i] = (int) round($p['valor'] * 100);
        }

        $resultado = [];
        $indice = 0;
        $totalFormas = count($pagamentos);

        foreach ($totais as $vendaId => $total) {
            $falta = (int) round($total * 100);
            $resultado[$vendaId] = [];

            while ($falta > 0 && $indice < $totalFormas) {
                if ($restante[$indice] <= 0) {
                    $indice++;
                    continue;
                }

                $usa = min($falta, $restante[$indice]);
                $resultado[$vendaId][] = [
                    'metodo'   => $pagamentos[$indice]['metodo'],
                    'valor'    => $usa / 100,
                    'bandeira' => $pagamentos[$indice]['bandeira'],
                    'parcelas' => $pagamentos[$indice]['parcelas'],
                ];
                $restante[$indice] -= $usa;
                $falta -= $usa;

                if ($restante[$indice] <= 0) {
                    $indice++;
                }
            }
        }

        // Sobra de pagamento (excedente) acompanha a última venda
        $ultimoId = array_key_last($totais);
        for ($i = $indice; $i < $totalFormas; $i++) {
            if ($restante[$i] > 0) {
                $resultado[$ultimoId][] = [
                    'metodo'   => $pagamentos[$i]['metodo'],
                    'valor'    => $restante[$i] / 100,
                    'bandeira' => $pagamentos[$i]['bandeira'],
                    'parcelas' => $pagamentos[$i]['parcelas'],
                ];
            }
        }

        return $resultado;
    }

    /**
     * Débitos (saldo de pagamentos parciais) em aberto de um cliente — soma todos os pets dele.
     *
     * @Route("/debitos/cliente/{clienteId}", name="clinica_pdv_debitos_cliente", methods={"GET"}, requirements={"clienteId"="\d+"})
     */
    public function debitosCliente(int $clienteId): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        $linhas = $this->getRepositorio(FinanceiroPendente::class)
            ->findSaldosAbertosPorCliente($estabelecimentoId, $clienteId);

        $total = 0.0;
        $debitos = [];
        foreach ($linhas as $l) {
            $valor = round((float) $l['valor'], 2);
            $total += $valor;
            $debitos[] = [
                'id' => (int) $l['id'],
                'valor' => $valor,
                'descricao' => $l['descricao'],
                'data' => $l['data'] ? (new \DateTime($l['data']))->format('d/m/Y') : '',
                'venda_id' => $l['venda_id'] ? (int) $l['venda_id'] : null,
                'pet_nome' => $l['pet_nome'],
            ];
        }

        return new JsonResponse(['ok' => true, 'total' => round($total, 2), 'debitos' => $debitos]);
    }

    /**
     * Recebe um débito (total ou uma parte). Quitado, ele sai do financeiro pendente.
     *
     * @Route("/debitos/{id}/receber", name="clinica_pdv_debito_receber", methods={"POST"}, requirements={"id"="\d+"})
     */
    public function receberDebito(int $id, Request $request): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        $contentType = $request->headers->get('Content-Type', '');
        $dados = str_contains($contentType, 'application/json')
            ? (json_decode($request->getContent(), true) ?? [])
            : $request->request->all();

        try {
            $resultado = $this->getRepositorio(FinanceiroPendente::class)->receberSaldo(
                $estabelecimentoId,
                $id,
                (float) str_replace(',', '.', (string) ($dados['valor'] ?? 0)),
                (string) ($dados['metodo'] ?? ''),
                !empty($dados['bandeira']) ? (string) $dados['bandeira'] : null
            );
        } catch (\InvalidArgumentException | \RuntimeException $e) {
            return new JsonResponse(['ok' => false, 'mensagem' => $e->getMessage()], 422);
        } catch (\Throwable $e) {
            $this->logger->error('Falha ao receber débito no PDV.', ['debito' => $id, 'erro' => $e->getMessage()]);
            return new JsonResponse(['ok' => false, 'mensagem' => 'Não foi possível registrar o recebimento. Tente novamente.'], 500);
        }

        return new JsonResponse([
            'ok' => true,
            'quitado' => $resultado['quitado'],
            'restante' => $resultado['restante'],
            'mensagem' => $resultado['quitado']
                ? 'Débito quitado! Ele saiu do financeiro pendente.'
                : 'Recebimento registrado. Resta R$ ' . number_format($resultado['restante'], 2, ',', '.') . ' em aberto.',
        ]);
    }

    /**
     * Registra nova venda
     *
     * @Route("/registrar", name="clinica_pdv_registrar", methods={"POST"})
     */
    public function registrar(Request $request): JsonResponse
    {
        $this->switchDB();

        try {
            $dados = json_decode($request->getContent(), true);
            $dto = RegistrarVendaDTO::fromArray($dados);

            // Valida DTO
            $errors = $dto->validate();
            if (!empty($errors)) {
                return new JsonResponse([
                    'ok' => false,
                    'msg' => implode(' ', $errors),
                ], 400);
            }

            // Processa venda via service
            $resultado = $this->pdvService->registrarVenda($dto);

            return new JsonResponse($resultado, $resultado['ok'] ? 200 : 400);

        } catch (\Exception $e) {
            return new JsonResponse([
                'ok' => false,
                'msg' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Registra saída de caixa
     *
     * @Route("/saida", name="clinica_pdv_saida", methods={"POST"})
     */
    public function registrarSaida(Request $request): JsonResponse
    {
        $this->switchDB();

        try {
            $dados = json_decode($request->getContent(), true);
            $dto = RegistrarSaidaDTO::fromArray($dados);

            // Valida DTO
            $errors = $dto->validate();
            if (!empty($errors)) {
                return new JsonResponse([
                    'ok' => false,
                    'msg' => implode(' ', $errors),
                ], 400);
            }

            // Processa saída via service
            $resultado = $this->caixaService->registrarSaida($dto);

            return new JsonResponse($resultado, $resultado['ok'] ? 200 : 400);

        } catch (\Exception $e) {
            return new JsonResponse([
                'ok' => false,
                'msg' => 'Erro ao registrar saída: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Tela de controle de caixa
     *
     * @Route("/caixa", name="clinica_pdv_caixa", methods={"GET"})
     */
    public function caixa(): Response
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $hoje = new \DateTime();
        $vendaRepo = $this->getRepositorio(Venda::class);

        // Busca resumo do caixa
        $resumoCaixa = $this->caixaService->getResumoDoDia();

        // Busca totais de vendas
        $totais = $vendaRepo->totalPorFormaPagamento($estabelecimentoId, $hoje);
        $totalGeral = $vendaRepo->totalGeralDoDia($estabelecimentoId, $hoje);

        return $this->render('clinica/pdv_caixa.html.twig', [
            'data' => $hoje,
            'registros' => $resumoCaixa['registros'],
            'entradas' => $resumoCaixa['entradas'],
            'saidas' => $resumoCaixa['saidas'],
            'saldo' => $resumoCaixa['saldo'],
            'totais' => $totais,
            'totalGeral' => $totalGeral,
        ]);
    }

    /**
     * Listagem de vendas
     *
     * @Route("/listar", name="clinica_pdv_listar", methods={"GET"})
     */
    public function listar(EntityManagerInterface $em): Response
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $conn = $em->getConnection();

        // SQL nativo para trazer o nome do pet na mesma consulta e evitar N+1.
        $sql = "SELECT v.id,
                       v.data,
                       v.cliente,
                       v.total,
                       v.metodo_pagamento AS metodoPagamento,
                       v.status,
                       v.pet_id AS petId,
                       p.nome AS petNome
                FROM homepet_{$estabelecimentoId}.venda v
                LEFT JOIN homepet_{$estabelecimentoId}.pet p ON p.id = v.pet_id
                WHERE v.estabelecimento_id = :estab
                ORDER BY v.data DESC";

        $vendas = $conn->fetchAllAssociative($sql, ['estab' => $estabelecimentoId]);

        return $this->render('clinica/pdv_listar.html.twig', [
            'vendas' => $vendas,
        ]);
    }

    /**
     * Atendimentos/serviços em aberto do tutor, agrupados por pet, para trazer à venda.
     *
     * @Route("/pendentes-cliente/{clienteId}", name="clinica_pdv_pendentes_cliente", methods={"GET"})
     */
    public function pendentesCliente(int $clienteId): JsonResponse
    {
        $this->switchDB();
        $baseId = $this->tenantContext->getEstabelecimentoId();

        $rows = $this->getRepositorio(\App\Entity\FinanceiroPendente::class)
            ->findAbertosPorCliente($baseId, $clienteId);

        // Agrupa por pet
        $petsMap = [];
        $total = 0.0;
        foreach ($rows as $r) {
            $petId = (int) $r['pet_id'];
            if (!isset($petsMap[$petId])) {
                $petsMap[$petId] = [
                    'pet_id' => $petId,
                    'pet_nome' => $r['pet_nome'],
                    'itens' => [],
                ];
            }
            $valor = (float) $r['valor'];
            $total += $valor;
            $petsMap[$petId]['itens'][] = [
                'id' => (int) $r['id'],
                'descricao' => $r['descricao'],
                'valor' => $valor,
            ];
        }

        return new JsonResponse([
            'success' => true,
            'pets' => array_values($petsMap),
            'total' => $total,
            'quantidade' => count($rows),
        ]);
    }

    /**
     * Marca as pendências como pagas depois de incluídas numa venda.
     *
     * @Route("/baixar-pendentes", name="clinica_pdv_baixar_pendentes", methods={"POST"})
     */
    public function baixarPendentes(Request $request): JsonResponse
    {
        $this->switchDB();
        $baseId = $this->tenantContext->getEstabelecimentoId();

        $dados = json_decode($request->getContent(), true);
        $ids = $dados['ids'] ?? $request->request->all('ids');

        if (empty($ids) || !is_array($ids)) {
            return new JsonResponse(['success' => false, 'mensagem' => 'Nenhuma pendência informada.'], 400);
        }

        try {
            $this->getRepositorio(\App\Entity\FinanceiroPendente::class)->marcarPagos($baseId, $ids);
            return new JsonResponse(['success' => true]);
        } catch (\Throwable $e) {
            return new JsonResponse(['success' => false, 'mensagem' => $e->getMessage()], 500);
        }
    }

    /**
     * Lista clientes para Select2
     *
     * @Route("/clientes/listar", name="clinica_pdv_clientes_listar", methods={"GET"})
     */
    public function listarClientes(): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $clienteRepo = $this->getRepositorio(Cliente::class);

        $clientes = $clienteRepo->findBy(['estabelecimentoId' => $estabelecimentoId]);

        $resultado = array_map(fn($c) => [
            'id' => $c->getId(),
            'nome' => $c->getNome(),
            'email' => $c->getEmail(),
            'telefone' => $c->getTelefone(),
        ], $clientes);

        return new JsonResponse($resultado);
    }

    /**
     * Autocomplete de tutores
     *
     * @Route("/autocomplete/tutor", name="clinica_autocomplete_tutor", methods={"GET"})
     */
    public function autocompleteTutor(Request $request): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $query = $request->query->get('query');
        $clienteRepo = $this->getRepositorio(Cliente::class);

        if (empty($query) || strlen($query) < 3) {
            return new JsonResponse([]);
        }

        $clientes = $clienteRepo->findByNomeLike($estabelecimentoId, $query);

        $resultado = array_map(fn($c) => [
            'id' => $c['id'],
            'nome' => $c['nome'],
        ], $clientes);

        return new JsonResponse($resultado);
    }

    /**
     * Busca pets de um tutor
     *
     * @Route("/pets-by-tutor/{id}", name="clinica_pets_by_tutor", methods={"GET"})
     */
    public function getPetsByTutor(int $id): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $clienteRepo = $this->getRepositorio(Cliente::class);

        $pets = $clienteRepo->listarPetsDoCliente($estabelecimentoId, $id);

        $resultado = array_map(fn($p) => [
            'id' => $p['id'],
            'nome' => $p['nome'],
        ], $pets);

        return new JsonResponse($resultado);
    }

    /**
     * Finaliza venda em carrinho (VERSÃO CORRIGIDA)
     *
     * @Route("/carrinho/finalizar/{id}", name="pdv_finalizar_carrinho", methods={"POST"})
     * 
     * MUDANÇAS APLICADAS:
     * - Mantém o fluxo de registrar no financeiro (linhas 510-553)
     * - Compatibiliza com PdvService que NÃO registra mais no financeiro prematuro
     * - Garante registro único quando a venda é finalizada
     */
    public function finalizarCarrinho(
        Request $request,
        int $id,
        AsaasNotaFiscalService $asaas
    ): JsonResponse {
        $this->switchDB();
        $vendaRepo = $this->getRepositorio(Venda::class);
        $fpRepo = $this->getRepositorio(FinanceiroPendente::class);
 
        try {
            // Aceita JSON ou form-data
            $contentType = $request->headers->get('Content-Type', '');
            $dados = str_contains($contentType, 'application/json')
            ? (json_decode($request->getContent(), true) ?? [])
            : $request->request->all();
 
            $metodo = $dados['metodo_pagamento'] ?? '';
            $bandeira = $dados['bandeira_cartao'] ?? null;
            $parcelas = !empty($dados['parcelas']) ? (int) $dados['parcelas'] : null;
            $usarCreditoReq = isset($dados['usar_credito'])
                ? (float) str_replace(',', '.', (string) $dados['usar_credito'])
                : 0.0;
            $deixarCreditoReq = isset($dados['deixar_credito'])
                ? (float) str_replace(',', '.', (string) $dados['deixar_credito'])
                : 0.0;
            // Pagamento parcial: o que faltar vira débito do cliente (financeiro pendente)
            $fiadoReq = !empty($dados['fiado']);
 
            // Formas de pagamento divididas (opcional)
            $pagamentos = [];
            foreach ($dados['pagamentos'] ?? [] as $p) {
                $m = trim((string) ($p['metodo'] ?? ''));
                $v = (float) ($p['valor'] ?? 0);
                if ($m === '' || $v <= 0) {
                    continue;
                }
                $pagamentos[] = [
                    'metodo'   => $m,
                    'valor'    => round($v, 2),
                    'bandeira' => !empty($p['bandeira']) ? (string) $p['bandeira'] : null,
                    'parcelas' => !empty($p['parcelas']) ? (int) $p['parcelas'] : null,
                ];
            }
 
            // Se veio pagamento dividido, ele define o método efetivo da venda
            if (!empty($pagamentos)) {
                foreach ($pagamentos as $p) {
                    if ($p['metodo'] === 'pendente') {
                        return new JsonResponse([
                            'status' => 'error',
                            'mensagem' => 'Pagamento dividido não pode incluir a forma "Pendente".',
                        ], 400);
                    }
                }
                $metodo = count($pagamentos) === 1 ? $pagamentos[0]['metodo'] : 'multiplo';
            } else {
                // Sem formas informadas não há o que parcelar: o pagamento é integral.
                $fiadoReq = false;
            }
 
            if (empty($metodo)) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Método de pagamento não informado.',
                ], 400);
            }
 
            // Data opcional (venda esquecida): só ontem ou hoje. Nula = fluxo normal (NOW()).
            try {
                $dataVenda = DataVendaRetroativa::resolver(
                    is_string($dados['data_venda'] ?? null) ? $dados['data_venda'] : null
                );
            } catch (\InvalidArgumentException $e) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => $e->getMessage(),
                ], 400);
            }
 
            $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
 
            // Busca a venda via SQL nativo (banco do tenant correto)
            $venda = $vendaRepo->findVendaCarrinho($estabelecimentoId, $id);
 
            if (!$venda) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Venda não encontrada ou já finalizada.',
                ], 404);
            }
 
            // Pagamento parcial só faz sentido com cliente/pet vinculado: é neles que o débito fica.
            if ($fiadoReq && empty($venda['pet_id'])) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Para deixar o restante como débito, a venda precisa ter um pet/cliente vinculado.',
                ], 400);
            }
 
            // Valida a soma quando há pagamento dividido (com pagamento parcial a soma pode ser menor)
            if (!empty($pagamentos) && !$fiadoReq) {
                $soma = array_sum(array_column($pagamentos, 'valor'));
                if ($soma + 0.01 < (float) $venda['total']) {
                    return new JsonResponse([
                        'status' => 'error',
                        'mensagem' => 'A soma das formas (R$ ' . number_format($soma, 2, ',', '.')
                            . ') é menor que o total da venda (R$ ' . number_format((float) $venda['total'], 2, ',', '.') . ').',
                    ], 400);
                }
            }
 
            // ── Aplica crédito do cliente, quando solicitado e disponível ─
            $totalVenda = (float) $venda['total'];
            $valorCreditoAbatido = 0.0;
            $clienteIdVenda = null;

            if ($usarCreditoReq > 0 && $metodo !== 'pendente' && !empty($venda['pet_id'])) {
                $pet = $this->getRepositorio(Pet::class)->find((int) $venda['pet_id']);
                $clienteIdVenda = $pet && method_exists($pet, 'getDono_Id') ? $pet->getDono_Id() : null;

                if ($clienteIdVenda) {
                    $creditoRepo = $this->getRepositorio(\App\Entity\ClienteCreditoMovimento::class);
                    $saldo = $creditoRepo->saldoDoCliente($estabelecimentoId, (int) $clienteIdVenda);
                    $valorCreditoAbatido = min(round($usarCreditoReq, 2), round($saldo, 2), round($totalVenda, 2));

                    if ($valorCreditoAbatido > 0) {
                        $creditoRepo->inserir(
                            $estabelecimentoId,
                            (int) $clienteIdVenda,
                            isset($venda['pet_id']) ? (int) $venda['pet_id'] : null,
                            'saida',
                            $valorCreditoAbatido,
                            'Abatido na venda #' . $id . ' (PDV)',
                            'venda',
                            (int) $id,
                            null
                        );
                    }
                }
            }

            $totalEfetivo = round($totalVenda - $valorCreditoAbatido, 2);

            // Pagamento parcial (fiado): o que faltar entre o total efetivo e o recebido vira
            // débito do cliente. A venda continua finalizada pelo valor cheio.
            $recebidoAgora = !empty($pagamentos) ? array_sum(array_column($pagamentos, 'valor')) : 0.0;
            $saldoDevedor = ($fiadoReq && $metodo !== 'pendente') ? round($totalEfetivo - $recebidoAgora, 2) : 0.0;
            $temSaldo = $saldoDevedor > 0.01;

            // Se o crédito cobriu tudo, não precisa gerar lançamento no financeiro.
            // Determina status final e registra no financeiro
            if ($metodo === 'pendente') {
                $statusFinal = 'Pendente';
                // Venda que já estava Pendente já tem o lançamento em financeiropendente:
                // não cria um segundo.
                if (($venda['status'] ?? null) !== 'Pendente' && $totalEfetivo > 0) {
                    $fpRepo->inserirPdv(
                        $estabelecimentoId,
                        $venda['cliente'] ?? 'Consumidor Final',
                        $totalEfetivo,
                        isset($venda['pet_id']) ? (int) $venda['pet_id'] : null,
                        $id
                    );
                }
            } else {
                $statusFinal = 'Paga';

                if (!empty($pagamentos)) {
                    // Pagamento dividido: a soma pode ser maior que o totalEfetivo
                    // (quando o crédito foi usado). Lança as formas pelo valor
                    // efetivo, proporcionalmente, para o financeiro não inflar.
                    $somaPagamentos = max(array_sum(array_column($pagamentos, 'valor')), 0.01);
                    foreach ($pagamentos as $p) {
                        // Com saldo devedor lança exatamente o que foi recebido (sem proporção).
                        $valorProporcional = $temSaldo
                            ? (float) $p['valor']
                            : ($totalEfetivo > 0
                                ? round(((float) $p['valor'] / $somaPagamentos) * $totalEfetivo, 2)
                                : 0.0);
                        if ($valorProporcional > 0) {
                            $vendaRepo->inserirFinanceiro(
                                $estabelecimentoId,
                                $p['metodo'],
                                $valorProporcional,
                                $venda['cliente'] ?? 'Consumidor Final',
                                $venda['pet_id'] ?? null,
                                $id,
                                $dataVenda
                            );
                        }
                        $vendaRepo->inserirPagamento(
                            $estabelecimentoId,
                            $id,
                            $p['metodo'],
                            (float) $p['valor'],
                            $p['bandeira'],
                            $p['parcelas'],
                            $dataVenda
                        );
                    }
                } elseif ($totalEfetivo > 0) {
                    $vendaRepo->inserirFinanceiro(
                        $estabelecimentoId,
                        $metodo,
                        $totalEfetivo,
                        $venda['cliente'] ?? 'Consumidor Final',
                        $venda['pet_id'] ?? null,
                        $id,
                        $dataVenda
                    );
                }
            }
 
            // Atualiza a venda com SQL nativo — banco correto garantido
            $ok = $vendaRepo->finalizarVenda(
                $estabelecimentoId,
                $id,
                $metodo,
                $statusFinal,
                $bandeira,
                $parcelas,
                $dataVenda
            );
 
            if (!$ok) {
                return new JsonResponse([
                    'status' => 'error',
                    'mensagem' => 'Não foi possível atualizar a venda. Tente novamente.',
                ], 500);
            }
 
            // Troco como crédito: registra entrada quando o caixa escolhe
            // reservar o excedente ao invés de devolver em dinheiro.
            if ($deixarCreditoReq > 0 && $metodo === 'dinheiro' && !empty($venda['pet_id'])) {
                $pet = $pet ?? $this->getRepositorio(Pet::class)->find((int) $venda['pet_id']);
                $clienteIdVenda = $clienteIdVenda ?? ($pet && method_exists($pet, 'getDono_Id') ? $pet->getDono_Id() : null);

                if ($clienteIdVenda) {
                    $creditoRepo = $this->getRepositorio(\App\Entity\ClienteCreditoMovimento::class);
                    $creditoRepo->inserir(
                        $estabelecimentoId,
                        (int) $clienteIdVenda,
                        (int) $venda['pet_id'],
                        'entrada',
                        round($deixarCreditoReq, 2),
                        'Troco guardado como crédito na venda #' . $id,
                        'venda',
                        (int) $id,
                        null
                    );
                }
            }

            // Venda que estava PENDENTE e agora foi paga: o lançamento em
            // financeiropendente sai da lista de pendentes (o valor já entrou em
            // financeiro como 'Pago' acima).
            if ($metodo !== 'pendente' && ($venda['status'] ?? null) === 'Pendente') {
                $fpRepo->baixarPorVenda(
                    $estabelecimentoId,
                    $id,
                    (float) $venda['total'],
                    isset($venda['pet_id']) ? (int) $venda['pet_id'] : null
                );
            }

            // Saldo do pagamento parcial vai para o financeiro pendente do cliente.
            // (Depois da baixa acima: uma venda que estava Pendente tem o lançamento antigo
            // encerrado e este novo guarda só o que ainda falta receber.)
            if ($temSaldo) {
                $fpRepo->inserirSaldoPdv(
                    $estabelecimentoId,
                    $venda['cliente'] ?? 'Consumidor Final',
                    $saldoDevedor,
                    (int) $venda['pet_id'],
                    $id
                );
            }

            // ── Emissão automática de NFS-e (Asaas) ──
            // (código mantido igual — não alterado)
            $notaFiscal = null;
 
            if ($metodo !== 'pendente' && $this->emissaoAutomaticaAtiva()) {
                $vendaEntity = $this->getRepositorio(Venda::class)->find($id);
                $this->restauraLoginDB();
 
                if ($vendaEntity && !empty($asaas->getConfig($estabelecimentoId)['api_key'])) {
                    try {
                        $resultadoNf = $asaas->emitir($vendaEntity);
                        $notaFiscal = [
                            'emitida' => true,
                            'asaas_invoice_id' => $resultadoNf['asaas_invoice_id'] ?? null,
                            'status' => $resultadoNf['status'] ?? null,
                        ];
                    } catch (NotaFiscalException | \Exception $e) {
                        $this->logger->error('Falha ao emitir NFS-e no fechamento do PDV.', [
                            'venda_id' => $id,
                            'erro' => $e->getMessage(),
                        ]);
                        $notaFiscal = ['emitida' => false, 'erro' => $e->getMessage()];
                    }
                }
            }
 
            return new JsonResponse([
                'status' => 'success',
                'mensagem' => 'Venda #' . $id . ' finalizada com sucesso!'
                    . ($temSaldo ? ' Débito de R$ ' . number_format($saldoDevedor, 2, ',', '.') . ' lançado para o cliente.' : ''),
                'saldo_devedor' => $temSaldo ? $saldoDevedor : 0.0,
                'nota_fiscal' => $notaFiscal,
            ]);
 
        } catch (\Exception $e) {
            return new JsonResponse([
                'status' => 'error',
                'mensagem' => 'Erro ao finalizar venda: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Retorna os dados de uma venda em JSON para pré-carregar o PDV via popup (sem usar sessão).
     *
     * @Route("/dados-venda/{id}", name="pdv_dados_venda", methods={"GET"})
     */
    public function dadosVenda(int $id, EntityManagerInterface $em): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        $venda = $em->getRepository(Venda::class)->findOneBy([
            'id' => $id,
            'estabelecimentoId' => $estabelecimentoId,
        ]);

        if (!$venda) {
            return new JsonResponse(['ok' => false, 'msg' => 'Venda não encontrada.'], 404);
        }

        $nomeCliente = $venda->getCliente() ?? 'Consumidor Final';
        $petId = $venda->getPetId();
        $nomePet = null;

        if ($petId) {
            $pet = $em->getRepository(Pet::class)->find($petId);
            if ($pet) {
                $nomePet = $pet->getNome();
            }
        }

        $itensEntities = $em->getRepository(VendaItem::class)->findBy(['vendaId' => $venda->getId()]);
        $itensNormalizados = $this->normalizarItensDaVenda($em, $itensEntities);

        return new JsonResponse([
            'ok' => true,
            'venda_id' => $venda->getId(),
            'status' => $venda->getStatus(),
            'cliente_nome' => $nomeCliente,
            'pet_id' => $petId,
            'pet_nome' => $nomePet,
            'itens' => $itensNormalizados,
            'total' => $venda->getTotal(),
            'observacao' => $venda->getObservacao(),
        ]);
    }

    /**
     * Busca vendas de um pet
     *
     * @Route("/pet/{petId}/vendas", name="clinica_pdv_pet_vendas", methods={"GET"})
     */
    public function vendasPorPet(int $petId, EntityManagerInterface $em): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();

        try {
            // Busca pet
            $pet = $em->getRepository(Pet::class)
                ->findOneBy(['id' => $petId, 'estabelecimentoId' => $estabelecimentoId]);

            if (!$pet) {
                return new JsonResponse(['ok' => false, 'msg' => 'Pet não encontrado'], 404);
            }

            // Busca vendas do pet
            $vendas = $em->getRepository(Venda::class)
                ->findByPet($estabelecimentoId, $petId);

            $vendasFormatadas = [];
            $totalGasto = 0;

            foreach ($vendas as $venda) {
                $totalGasto += $venda->getTotal();

                $itens = $em->getRepository(VendaItem::class)
                    ->findBy(['vendaId' => $venda->getId()]);

                $itensFormatados = array_map(fn($item) => [
                    'produto' => $item->getProdutoNome(),
                    'quantidade' => $item->getQuantidade(),
                    'valor_unitario' => number_format($item->getValorUnitario(), 2, ',', '.'),
                    'subtotal' => number_format($item->getSubtotal(), 2, ',', '.'),
                ], $itens);

                $vendasFormatadas[] = [
                    'id' => $venda->getId(),
                    'data' => $venda->getData()->format('d/m/Y H:i'),
                    'total' => number_format($venda->getTotal(), 2, ',', '.'),
                    'metodo_pagamento' => $venda->getMetodoPagamento(),
                    'observacao' => $venda->getObservacao(),
                    'itens' => $itensFormatados,
                ];
            }

            return new JsonResponse([
                'ok' => true,
                'pet' => [
                    'id' => $pet->getId(),
                    'nome' => $pet->getNome(),
                    'especie' => $pet->getEspecie(),
                    'raca' => $pet->getRaca(),
                ],
                'vendas' => $vendasFormatadas,
                'resumo' => [
                    'total_vendas' => count($vendas),
                    'total_gasto' => number_format($totalGasto, 2, ',', '.'),
                    'ticket_medio' => count($vendas) > 0
                    ? number_format($totalGasto / count($vendas), 2, ',', '.')
                    : '0,00',
                ],
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'ok' => false,
                'msg' => 'Erro: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Resumo de vendas do dia
     *
     * @Route("/resumo-dia", name="clinica_pdv_resumo_dia", methods={"GET"})
     */
    public function resumoDia(Request $request): JsonResponse
    {
        $this->switchDB();
        $estabelecimentoId = $this->tenantContext->getEstabelecimentoId();
        $vendaRepo = $this->getRepositorio(Venda::class);

        try {
            $dataParam = $request->query->get('data');
            $data = $dataParam ? new \DateTime($dataParam) : new \DateTime();

            $resumo = $vendaRepo->getResumoDoDia($estabelecimentoId, $data);
            $porMetodo = $vendaRepo->totalPorFormaPagamento($estabelecimentoId, $data);

            return new JsonResponse([
                'ok' => true,
                'data' => $data->format('d/m/Y'),
                'resumo' => [
                    'quantidade_vendas' => $resumo['quantidade_vendas'],
                    'total_vendas' => number_format($resumo['total_vendas'], 2, ',', '.'),
                    'ticket_medio' => number_format($resumo['ticket_medio'], 2, ',', '.'),
                    'por_metodo' => $porMetodo,
                ],
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'ok' => false,
                'msg' => 'Erro: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Helpers privados
     */

    /**
     * Resolve o nome de exibição de um VendaItem.
     *
     * Itens gravados antes da refatoração tinham o ID numérico no campo
     * produtoNome (snapshot). Este método detecta esse caso e busca o nome
     * real no cadastro de Produtos ou Serviços, com fallback graceful.
     */
    /**
     * Liga/desliga a emissão automática de NFS-e no fechamento do PDV.
     *
     * Controlada pela variável de ambiente ASSAS_INIT:
     *   ASSAS_INIT=on   → emite automaticamente
     *   ASSAS_INIT=off  (ou ausente) → não emite
     * Aceita também 'true'/'1'/'enabled' como ligado.
     */
    private function emissaoAutomaticaAtiva(): bool
    {
        $flag = $_ENV['ASSAS_INIT'] ?? $_SERVER['ASSAS_INIT'] ?? 'off';

        return in_array(strtolower(trim((string) $flag)), ['on', 'true', '1', 'enabled'], true);
    }

    /**
     * Resolve o ID numérico de um VendaItem garantindo que nunca seja null/zero.
     *
     * Itens legados podem ter produtoId=null e o ID numérico guardado
     * no snapshot do nome (campo produto). Este método normaliza os dois casos.
     */
    private function resolverProdutoId(VendaItem $item): int
    {
        if ($item->getProdutoId()) {
            return $item->getProdutoId();
        }

        // Fallback: snapshot numérico (dado legado)
        $snapshot = $item->getProduto();
        if ($snapshot !== null && is_numeric(trim($snapshot))) {
            return (int) trim($snapshot);
        }

        // Sem ID válido — retorna 0 (tratado no EstoqueService)
        return 0;
    }

    /**
     * Converte os VendaItem de uma venda no payload que o carrinho do PDV lê.
     *
     * ── Por que o id leva o sufixo "#<id do venda_item>" ─────────────────────
     * O carrinho do PDV identifica cada linha pelo campo `id` ('serv_12').
     * Numa venda de atendimento com 2+ pets, o MESMO serviço aparece uma vez
     * por pet (coleta de sangue do Rex + coleta de sangue da Mel) — duas linhas
     * de venda_item com o mesmo produto_id. Com o id repetido, o JS tratava as
     * duas como a mesma linha: remover uma apagava as duas e alterar a
     * quantidade só pegava a primeira, e o total do caixa saía diferente do
     * total lançado na ficha.
     *
     * O sufixo torna cada linha única sem quebrar quem extrai o id numérico —
     * PdvService::extrairIdNumerico() e EstoqueService::extrairProdutoId()
     * fazem cast para int, e 'serv_12#48' → '12#48' → 12.
     *
     * ── Por que o unitário é o efetivo ───────────────────────────────────────
     * O carrinho recalcula subtotal = quantidade × unitário; ele não tem
     * desconto por linha. Repassando o unitário cheio, uma venda lançada com
     * desconto na ficha aparecia no caixa por um valor maior que o da venda.
     * Repassamos o unitário já líquido para o carrinho fechar no mesmo total,
     * mantendo o valor de tabela em `valor_unitario_bruto` para exibição.
     *
     * @param VendaItem[] $itens
     * @return array<int, array<string, mixed>>
     */
    private function normalizarItensDaVenda(EntityManagerInterface $em, array $itens): array
    {
        $normalizados = [];

        foreach ($itens as $item) {
            $tipo = $item->getTipo(); // já normalizado para lowercase na entity
            $produtoId = $this->resolverProdutoId($item); // trata legado com produtoId null

            $idFrontend = ($tipo === 'produto' ? 'prod_' : 'serv_') . $produtoId;

            if ($item->getId()) {
                $idFrontend .= '#' . $item->getId();
            }

            $quantidade = max(1, (int) $item->getQuantidade());
            $unitario   = (float) $item->getValorUnitario();
            $subtotal   = (float) $item->getSubtotal();
            $desconto   = round(($unitario * $quantidade) - $subtotal, 2);

            $normalizados[] = [
                'id' => $idFrontend,
                'nome' => $this->resolverNomeItem($em, $item),
                'tipo' => ucfirst($tipo),
                'quantidade' => $quantidade,
                'valor_unitario' => $desconto > 0 ? round($subtotal / $quantidade, 2) : $unitario,
                'valor_unitario_bruto' => $unitario,
                'desconto' => max(0.0, $desconto),
                'subtotal' => $subtotal,
            ];
        }

        return $normalizados;
    }

    private function resolverNomeItem(EntityManagerInterface $em, VendaItem $item): string
    {
        $snapshot = $item->getProdutoNome();
        $produtoId = $item->getProdutoId();

        // Se o snapshot não é numérico, é um nome válido — retorna direto
        if ($snapshot !== null && !is_numeric(trim($snapshot))) {
            return $snapshot;
        }

        // Snapshot é numérico (dado legado) ou nulo — busca no cadastro pelo produtoId
        $idBusca = $produtoId ?? (int) trim((string) $snapshot);

        if (!$idBusca) {
            return $snapshot ?? 'Item sem descrição';
        }

        if ($item->getTipo() === 'produto') {
            $entidade = $em->getRepository(Produto::class)->find($idBusca);
        } else {
            $entidade = $em->getRepository(Servico::class)->find($idBusca);
        }

        return $entidade ? $entidade->getNome() : ($snapshot ?? "Item #{$idBusca}");
    }

    private function normalizarItens(array $produtos, array $servicos): array
    {
        $itens = [];

        foreach ($produtos as $p) {
            $itens[] = [
                "id" => "prod_" . $p->getId(),
                "nome" => $p->getNome(),
                "valor" => $p->getPrecoVenda() ?? 0.0,
                "estoque" => $p->getEstoqueAtual() ?? 0,
                "tipo" => "Produto",
                "descricao" => $p->getNome() ?? "",
            ];
        }

        foreach ($servicos as $s) {
            $itens[] = [
                "id" => "serv_" . $s->getId(),
                "nome" => $s->getNome(),
                "valor" => $s->getValor() ?? 0.0,
                "estoque" => null,
                "tipo" => "Serviço",
                "descricao" => $s->getDescricao() ?? "",
            ];
        }

        usort($itens, fn($a, $b) => strcmp($a["nome"], $b["nome"]));

        return $itens;
    }

    private function buscarItensVenda(EntityManagerInterface $em, int $vendaId): array
    {
        $itens = $em->getRepository(VendaItem::class)->findBy(['vendaId' => $vendaId]);

        return array_map(fn($item) => [
            'descricao' => $this->resolverNomeItem($em, $item),
            'quantidade' => $item->getQuantidade(),
            'valor_unitario' => $item->getValorUnitario(),
            'subtotal' => $item->getSubtotal(),
        ], $itens);
    }
}