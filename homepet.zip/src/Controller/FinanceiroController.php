<?php

namespace App\Controller;

use App\Entity\Financeiro;
use App\Entity\Pet;
use App\Entity\FinanceiroPendente;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\HttpFoundation\JsonResponse;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/**
 * @Route("dashboard/financeiro")
 */
class FinanceiroController extends DefaultController
{
    /**
     * Abas da tela. Cada uma é um link (?aba=...) e carrega só o próprio conteúdo.
     */
    private const ABAS = ['diario', 'clinica', 'banho_tosa', 'hospedagem', 'fiado', 'fluxo', 'relatorio', 'inativos'];

    /**
     * @Route("/", name="financeiro_index")
     */
    public function index(Request $request): Response
    {
        if ($resp = $this->negarSeNaoFinanceiro()) { return $resp; }

        $this->switchDB();
        $baseId = $this->getIdBase();
        $financeiroRepo = $this->getRepositorio(Financeiro::class);
        $financeiroPendenteRepo = $this->getRepositorio(FinanceiroPendente::class);
        $financeiroRepo->regulaBase();

        $aba = (string) $request->query->get('aba', 'diario');
        if ($aba === 'pendente') {
            $aba = 'fiado'; // links antigos
        }
        if (!in_array($aba, self::ABAS, true)) {
            $aba = 'diario';
        }

        $dataDiario = $request->query->get('data') ? date('Y-m-d', strtotime($request->query->get('data'))) : date('Y-m-d');

        // --- Resumo do topo (aparece em todas as abas; uma consulta barata cada) ---
        $financeirosDiarios = $financeiroRepo->findTotalByDate($baseId, $dataDiario);
        $totalMes = array_sum(array_column($financeiroRepo->getRelatorioPorPeriodo(
            $baseId,
            new \DateTime('first day of this month'),
            new \DateTime('last day of this month')
        ), 'total'));

        $resumo = [
            'caixa_dia'   => array_sum(array_column($financeirosDiarios, 'total_valor')),
            'fiado_total' => $financeiroPendenteRepo->somarDebitosPendentes($baseId),
            'fiado_qtd'   => $financeiroPendenteRepo->contarDebitosPendentes($baseId),
            'mes'         => $totalMes,
        ];

        $data = [
            'aba'        => $aba,
            'resumo'     => $resumo,
            'data'       => $dataDiario,
            'mes_inicio' => $request->query->get('mes_inicio', (new \DateTime('first day of this month'))->format('Y-m')),
            'mes_fim'    => $request->query->get('mes_fim', (new \DateTime('last day of this month'))->format('Y-m')),
        ];

        // --- Conteúdo da aba aberta ---
        switch ($aba) {
            case 'diario':
                $data['financeiros'] = $financeirosDiarios;
                break;

            case 'clinica':
            case 'banho_tosa':
            case 'hospedagem':
                $data['financeiros'] = $financeiroRepo->findTotalByDateAndOrigem($baseId, $dataDiario, $aba);
                break;

            case 'fiado':
                $data['pendentes'] = $financeiroPendenteRepo->findAllClinica($baseId);
                break;

            case 'relatorio':
                $dataInicio = new \DateTime($data['mes_inicio'] . '-01');
                $dataFim = (new \DateTime($data['mes_fim'] . '-01'))->modify('last day of this month');
                $data['relatorio'] = $financeiroRepo->getRelatorioPorPeriodo($baseId, $dataInicio, $dataFim);
                break;

            case 'inativos':
                $inativos = array_merge(
                    $financeiroRepo->findInativos($baseId),
                    $financeiroPendenteRepo->buscaInativosPendentes($baseId)
                );
                usort($inativos, function ($a, $b) {
                    return strtotime($b['data']) - strtotime($a['data']);
                });
                $data['inativos'] = $inativos;
                break;

            case 'fluxo':
                $dataFluxo = $request->query->get('data_fluxo') ? new \DateTime($request->query->get('data_fluxo')) : new \DateTime();
                $data['data_fluxo'] = $dataFluxo;
                $data['fluxo_caixa'] = $this->getFluxoCaixa($baseId, $dataFluxo);
                break;
        }

        return $this->render('financeiro/index.html.twig', $data);
    }

    /**
     * @Route("/novo", name="financeiro_novo")
     */
    public function novo(Request $request): Response
    {
        if ($resp = $this->negarSeNaoFinanceiro()) { return $resp; }

        $this->switchDB();
        $baseId = $this->getIdBase();
        $financeiroRepo = $this->getRepositorio(Financeiro::class);
        $petRepo = $this->getRepositorio(Pet::class);

        if ($request->isMethod('POST')) {
            $financeiro = new Financeiro();
            $financeiro->setDescricao($request->request->get('descricao'));
            $financeiro->setValor((float) $request->request->get('valor'));
            $financeiro->setData(new \DateTime($request->request->get('data')));
            $financeiro->setPetId($request->request->get('pet_id') !== '' ? (int) $request->request->get('pet_id') : null);
            $financeiro->setEstabelecimentoId($baseId);

            $financeiroRepo->save($baseId, $financeiro);
            return $this->redirectToRoute('financeiro_index');
        }

        return $this->render('financeiro/novo.html.twig', [
            'pets' => $petRepo->findAllPets($baseId)
        ]);
    }

    /**
     * @Route("/editar/{id}", name="financeiro_editar")
     * 
     * CORRIGIDO: findFinanceiro agora retorna array, não objeto
     */
    public function editar(Request $request, int $id): Response
    {
        if ($resp = $this->negarSeNaoFinanceiro()) { return $resp; }

        $this->switchDB();
        $baseId = $this->getIdBase();
        $financeiroRepo = $this->getRepositorio(Financeiro::class);
        $petRepo = $this->getRepositorio(Pet::class);
        
        // findFinanceiro agora retorna array (não objeto)
        $financeiroData = $financeiroRepo->findFinanceiro($baseId, $id);

        if (!$financeiroData) {
            throw $this->createNotFoundException('O registro financeiro não foi encontrado');
        }

        if ($request->isMethod('POST')) {
            // Reconstrói objeto Financeiro a partir do array
            $financeiro = new Financeiro();
            $financeiro->setId($id);
            $financeiro->setDescricao($request->request->get('descricao'));
            $financeiro->setValor((float) $request->request->get('valor'));
            $financeiro->setData(new \DateTime($request->request->get('data')));
            $financeiro->setPetId($request->request->get('pet_id') !== '' ? (int) $request->request->get('pet_id') : null);

            $financeiroRepo->update($baseId, $financeiro);
            return $this->redirectToRoute('financeiro_index');
        }

        return $this->render('financeiro/editar.html.twig', [
            'financeiro' => $financeiroData,  // Passa array para view
            'pets'       => $petRepo->findAllPets($baseId)
        ]);
    }

    /**
     * @Route("/deletar/{id}", name="financeiro_deletar")
     */
    public function deletar(int $id): Response
    {
        if ($resp = $this->negarSeNaoFinanceiro()) { return $resp; }

        $this->switchDB();
        $baseId = $this->getIdBase();
        $financeiroRepo = $this->getRepositorio(Financeiro::class);

        $financeiro = $financeiroRepo->findFinanceiro($baseId, $id);

        if (!$financeiro) {
            throw $this->createNotFoundException('O registro financeiro não foi encontrado');
        }

        $financeiroRepo->delete($baseId, $id);
        return $this->redirectToRoute('financeiro_index');
    }

    /**
     * @Route("/pendente/confirmar/{id}", name="financeiro_confirmar_pagamento", methods={"POST"})
     */
    public function confirmarPagamento(int $id, Request $request): Response
    {
        if ($resp = $this->negarSeNaoFinanceiro()) { return $resp; }

        $this->switchDB();
        $baseId = $this->getIdBase();
        $financeiroPendenteRepository = $this->getRepositorio(FinanceiroPendente::class);

        $financeiroPendente = $financeiroPendenteRepository->findPendenteById($baseId, $id);

        if (!$financeiroPendente) {
            throw $this->createNotFoundException('Registro financeiro pendente não encontrado.');
        }

        // Débito de pagamento parcial (fiado do PDV): recebe o que falta SEM criar outra venda
        // (a venda de origem já foi contada), registra a entrada e tira o débito do pendente.
        if (($financeiroPendente['origem'] ?? null) === \App\Repository\FinanceiroPendenteRepository::ORIGEM_SALDO) {
            try {
                $r = $financeiroPendenteRepository->receberSaldo(
                    $baseId,
                    $id,
                    (float) $financeiroPendente['valor'],
                    (string) $request->request->get('metodo_pagamento', 'dinheiro')
                );
                $this->addFlash('success', 'Débito de ' . $r['cliente'] . ' quitado (R$ ' . number_format($r['pago'], 2, ',', '.') . '). Ele saiu do pendente e ficou no histórico.');
            } catch (\Throwable $e) {
                $this->addFlash('danger', 'Não foi possível quitar o débito: ' . $e->getMessage());
            }

            return $this->redirectToRoute('financeiro_index', ['aba' => 'fiado']);
        }

        // Usa o método do repository que já cria a venda com origem correta
        $financeiroPendenteRepository->confirmarPagamento($baseId, $id);

        $this->addFlash('success', 'Pagamento confirmado e movido para o caixa correspondente.');

        return $this->redirectToRoute('financeiro_index', ['aba' => 'fiado']);
    }

    /**
     * @Route("/pendente/deletar/{id}", name="financeiro_deletar_pendente", methods={"POST"})
     */
    public function deletarPendente(int $id): Response
    {
        if ($resp = $this->negarSeNaoFinanceiro()) { return $resp; }

        $this->switchDB();
        $baseId = $this->getIdBase();
        $financeiroPendenteRepository = $this->getRepositorio(FinanceiroPendente::class);

        $financeiroPendente = $financeiroPendenteRepository->findPendenteById($baseId, $id);

        if (!$financeiroPendente) {
            throw $this->createNotFoundException('Registro financeiro pendente não encontrado.');
        }

        $financeiroPendenteRepository->deletePendente($baseId, $id);

        $this->addFlash('success', 'Registro pendente excluído com sucesso.');

        return $this->redirectToRoute('financeiro_index', ['aba' => 'fiado']);
    }

    /**
     * @Route("/relatorio/export", name="financeiro_relatorio_export")
     */
    public function exportRelatorioExcel(Request $request): Response
    {
        if ($resp = $this->negarSeNaoFinanceiro()) { return $resp; }

        $this->switchDB();
        $baseId = $this->getIdBase();
        $financeiroRepo = $this->getRepositorio(Financeiro::class);

        $mesInicio = $request->query->get('mes_inicio');
        $mesFim = $request->query->get('mes_fim');

        $dataInicio = $mesInicio ? new \DateTime($mesInicio . '-01') : new \DateTime('first day of this month');
        $dataFim = $mesFim ? new \DateTime($mesFim . '-01') : new \DateTime('last day of this month');
        $dataFim->modify('last day of this month');

        $relatorio = $financeiroRepo->getRelatorioPorPeriodo($baseId, $dataInicio, $dataFim);

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $sheet->setCellValue('A1', 'Data');
        $sheet->setCellValue('B1', 'Total');

        $row = 2;
        foreach ($relatorio as $item) {
            $sheet->setCellValue('A' . $row, \PhpOffice\PhpSpreadsheet\Shared\Date::PHPToExcel(new \DateTime($item['data'])));
            $sheet->getStyle('A' . $row)->getNumberFormat()->setFormatCode('DD/MM/YYYY');
            $sheet->setCellValue('B' . $row, $item['total']);
            $row++;
        }

        $writer = new Xlsx($spreadsheet);
        $fileName = 'relatorio_financeiro.xlsx';
        $temp_file = tempnam(sys_get_temp_dir(), $fileName);
        $writer->save($temp_file);

        return $this->file($temp_file, $fileName, ResponseHeaderBag::DISPOSITION_ATTACHMENT);
    }

    /**
     * @Route("/fluxo/debug", name="financeiro_fluxo_debug")
     */
    public function debugFluxo(Request $request): Response
    {
        if ($resp = $this->negarSeNaoFinanceiro()) { return $resp; }

        $this->switchDB();
        $baseId = $this->getIdBase();
        $data = new \DateTime();

        $fluxo = $this->getFluxoCaixa($baseId, $data);

        return new JsonResponse([
            'total_entradas'       => $fluxo['total_entradas'],
            'total_saidas'         => $fluxo['total_saidas'],
            'saldo'                => $fluxo['saldo'],
            'quantidade_movimentos' => count($fluxo['movimentos']),
            'movimentos'           => $fluxo['movimentos']
        ]);
    }

    /**
     * Método auxiliar para buscar o fluxo de caixa consolidado
     */
    private function getFluxoCaixa(int $baseId, \DateTime $data): array
    {
        $inicioDia = (clone $data)->setTime(0, 0, 0);
        $fimDia = (clone $data)->setTime(23, 59, 59);
        $this->switchDB();
        $em = $this->getDoctrine()->getManager();

        // 🔹 1. Busca ENTRADAS da tabela venda (todas as vendas pagas - exclui Pendente, Inativa e Carrinho)
        $entradasVenda = $em->getRepository(\App\Entity\Venda::class)
            ->createQueryBuilder('v')
            ->where('v.estabelecimentoId = :estab')
            ->andWhere('v.data BETWEEN :inicio AND :fim')
            ->andWhere('v.status NOT IN (:statusExcluidos)')
            ->setParameter('estab', $baseId)
            ->setParameter('inicio', $inicioDia)
            ->setParameter('fim', $fimDia)
            ->setParameter('statusExcluidos', ['Pendente', 'Inativa', 'Aberta'])
            ->orderBy('v.data', 'ASC')
            ->getQuery()
            ->getResult();

        // 🔹 2. Busca movimentos do Caixa (PDV) - APENAS SAÍDAS
        $movimentosCaixa = $em->getRepository(\App\Entity\CaixaMovimento::class)
            ->createQueryBuilder('c')
            ->where('c.estabelecimentoId = :estab')
            ->andWhere('c.data BETWEEN :inicio AND :fim')
            ->andWhere('c.tipo = :tipo')
            ->setParameter('estab', $baseId)
            ->setParameter('inicio', $inicioDia)
            ->setParameter('fim', $fimDia)
            ->setParameter('tipo', 'SAIDA')
            ->orderBy('c.data', 'ASC')
            ->getQuery()
            ->getResult();

        // 🔹 3. Consolida tudo em um array único
        $movimentos = [];
        $totalEntradas = 0;
        $totalSaidas = 0;

        // Adiciona entradas das vendas
        foreach ($entradasVenda as $v) {
            $valor = floatval($v->getTotal());
            if ($valor > 0) {
                $totalEntradas += $valor;
                $movimentos[] = [
                    'data'      => $v->getData(),
                    'descricao' => $v->getCliente() . ' - ' . ucfirst($v->getOrigem()),
                    'origem'    => ucfirst(str_replace('_', ' ', $v->getOrigem())),
                    'metodo'    => $v->getMetodoPagamento() ?? '-',
                    'tipo'      => 'ENTRADA',
                    'valor'     => $valor
                ];
            }
        }

        // Adiciona movimentos do caixa (PDV) - Apenas saídas manuais
        foreach ($movimentosCaixa as $c) {
            $valor = floatval($c->getValor());
            if ($valor > 0) {
                $totalSaidas += $valor;
                $movimentos[] = [
                    'data'      => $c->getData(),
                    'descricao' => $c->getDescricao(),
                    'origem'    => 'PDV - Saída Manual',
                    'metodo'    => 'Caixa',
                    'tipo'      => 'SAIDA',
                    'valor'     => $valor
                ];
            }
        }

        // 🔹 4. Ordena por data
        usort($movimentos, function ($a, $b) {
            return $a['data'] <=> $b['data'];
        });

        return [
            'movimentos'     => $movimentos,
            'total_entradas' => $totalEntradas,
            'total_saidas'   => $totalSaidas,
            'saldo'          => $totalEntradas - $totalSaidas
        ];
    }
}