<?php

namespace App\Controller\Clinica;

use App\Entity\Box;
use App\Entity\Cliente;
use App\Entity\Consulta;
use App\Entity\DocumentoModelo;
use App\Entity\Financeiro;
use App\Entity\FinanceiroPendente;
use App\Entity\Internacao;
use App\Entity\InternacaoExecucao;
use App\Entity\InternacaoPrescricao;
use App\Entity\Medicamento;
use App\Entity\Pet;
use App\Entity\Servico;
use App\Entity\Vacina;
use App\Entity\Veterinario;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Service\GeradorpdfService;
use App\Controller\DefaultController;


/**
 * @Route("dashboard/clinica")
 */
class InternacaoController extends DefaultController
{


    /**
     * @Route("/pet/{petId}/internacao/nova", name="clinica_nova_internacao", methods={"GET", "POST"})
     */
    public function novaInternacao(Request $request, int $petId): Response
    {
        $this->switchDB();
        $baseId = $this->getIdBase();

        $internacaoRepo  = $this->getRepositorio(Internacao::class);
        $veterinarioRepo = $this->getRepositorio(Veterinario::class);
        $boxRepo         = $this->getRepositorio(\App\Entity\Box::class);

        $pet = $this->getRepositorio(Pet::class)->findPetById($baseId, $petId);
        if (!$pet) {
            throw $this->createNotFoundException('Pet não encontrado.');
        }

        $veterinarios = $veterinarioRepo->findBy(['estabelecimentoId' => $baseId, 'status' => 'ativo']);

        // ── REAL: busca boxes disponíveis do estabelecimento ──────────
        $boxes = $boxRepo->findDisponiveisParaSelect($baseId);

        if ($request->isMethod('POST')) {
            $internacao = new Internacao();
            $donoId     = $pet['dono_id'] ?? null;

            $internacao->setPetId($petId);
            $internacao->setDonoId($donoId);
            $internacao->setEstabelecimentoId($baseId);
            $internacao->setDataInicio(new \DateTime());
            $internacao->setStatus('ativa');
            $internacao->setMotivo((string) $request->get('queixa'));
            $internacao->setSituacao((string) $request->get('situacao'));
            $internacao->setRisco((string) $request->get('risco'));
            $internacao->setVeterinarioId((int) $request->get('veterinario_id'));

            $boxNumero = (string) $request->get('box');
            $internacao->setBox($boxNumero);

            $altaPrevistaStr = trim((string) $request->get('alta_prevista'));
            if ($altaPrevistaStr !== '') {
                try {
                    $internacao->setAltaPrevista(new \DateTime($altaPrevistaStr));
                } catch (\Exception $e) {
                    $internacao->setAltaPrevista(null);
                }
            }

            $internacao->setDiagnostico((string) $request->get('diagnostico'));
            $internacao->setPrognostico((string) $request->get('prognostico'));
            $internacao->setAnotacoes((string) $request->get('alergias_marcacoes'));

            $novoId = $internacaoRepo->inserirInternacao($baseId, $internacao);

            // ── Marca o box como ocupado ──────────────────────────────
            if ($boxNumero !== '') {
                $boxRepo->ocupar($baseId, $boxNumero);
            }

            $internacaoRepo->inserirEvento(
                $baseId, $novoId, $petId,
                'Internação', 'Internação iniciada',
                sprintf(
                    'Motivo: %s | Situação: %s | Risco: %s | Box: %s',
                    (string) $internacao->getMotivo(),
                    (string) $internacao->getSituacao(),
                    (string) $internacao->getRisco(),
                    $boxNumero ?: 'não definido'
                ),
                new \DateTime()
            );

            $this->addFlash('success', 'Internação registrada com sucesso!');
            return $this->redirectToRoute('clinica_ficha_internacao', ['id' => $novoId]);
        }

        return $this->render('clinica/nova_internacao.html.twig', [
            'pet'          => $pet,
            'veterinarios' => $veterinarios,
            'boxes'        => $boxes,
        ]);
    }


    /**
     * Gera a tela de impressão da Ficha de Internação — Controle Completo de Plantão.
     * Replica o layout do formulário físico usado pela equipe veterinária,
     * com grade de horários de medicação (07h–02h), checkboxes de execução,
     * controle de parâmetros e campo de observações.
     *
     * @Route("/internacao/{id}/imprimir-ficha", name="clinica_internacao_imprimir_ficha", methods={"GET"})
     */
    public function imprimirFicha(
        int                    $id,
        EntityManagerInterface $em
    ): Response {
        $this->switchDB();
        $baseId = $this->getIdBase();
        $internacaoRepo = $this->getRepositorio(Internacao::class);
 
        // ── 1. Dados principais da internação ─────────────────────────────
        $internacao = $internacaoRepo->findInternacaoCompleta($baseId, $id);
        if (!$internacao) {
            throw $this->createNotFoundException('Internação não encontrada.');
        }
 
        // ── 2. Busca prescrições ativas da internação ──────────────────────
        // IMPORTANTE: Usa método customizado que filtra EXPLICITAMENTE por internacaoId
        // para evitar carregar prescrições de outras internações
        $prescricoes = $em->getRepository(InternacaoPrescricao::class)
            ->findByInternacao($id);
 
        // ── 3. Horários-grade que aparecem na ficha física ─────────────────
        // Grade completa de 24h: cobre todos os horários do dia e as madrugadas,
        // começando às 07h (hora de abertura da clínica) e dando a volta até 06h.
        $horasGrade = [];
        for ($i = 7; $i <= 23; $i++) {
            $horasGrade[] = str_pad((string) $i, 2, '0', STR_PAD_LEFT) . 'h';
        }
        for ($i = 0; $i <= 6; $i++) {
            $horasGrade[] = str_pad((string) $i, 2, '0', STR_PAD_LEFT) . 'h';
        }
 
        // ── 4. Mapeia execuções confirmadas por prescrição e hora ──────────
        //      Estrutura: execucoesPorPrescricao[prescricaoId] = ['07h', '13h', ...]
        $execucoesPorPrescricao = [];
 
        if (!empty($prescricoes)) {
            // Busca todos os eventos de prescrição desta internação
            $todosEventos = $em->getRepository(\App\Entity\InternacaoEvento::class)
                ->createQueryBuilder('e')
                ->where('e.internacaoId = :internacaoId')
                ->andWhere('e.tipo = :tipo')
                ->setParameter('internacaoId', $id)
                ->setParameter('tipo', 'prescricao')
                ->getQuery()
                ->getResult();
 
            $eventoIds = array_map(fn($e) => $e->getId(), $todosEventos);
 
            if (!empty($eventoIds)) {
                // Busca execuções confirmadas
                $execucoesResult = $em->getRepository(\App\Entity\InternacaoExecucao::class)
                    ->createQueryBuilder('ex')
                    ->where('ex.prescricaoId IN (:eventoIds)')
                    ->andWhere('ex.status = :status')
                    ->setParameter('eventoIds', $eventoIds)
                    ->setParameter('status', 'confirmado')
                    ->getQuery()
                    ->getResult();
 
                // Agrupa por prescricaoId -> lista de horas executadas
                foreach ($execucoesResult as $exec) {
                    $pid  = $exec->getPrescricaoId();
                    $hora = $exec->getDataExecucao()
                        ? $exec->getDataExecucao()->format('H') . 'h'
                        : null;
 
                    if ($hora) {
                        // Normaliza para o formato da grade (ex: "07h" não "7h")
                        $horaNorm = str_pad((int) $exec->getDataExecucao()->format('H'), 2, '0', STR_PAD_LEFT) . 'h';
                        $execucoesPorPrescricao[$pid][] = ['hora' => $horaNorm];
                    }
                }
            }
        }
 
        // ── 5. Renderiza o template de impressão (sem layout base) ─────────
        return $this->render('clinica/ficha_impressao.html.twig', [
            'internacao'              => $internacao,
            'prescricoes'             => $prescricoes,
            'horas_grade'             => $horasGrade,
            'execucoes_por_prescricao'=> $execucoesPorPrescricao,
        ]);
    }

    /**
     * @Route("/internacao/{id}/ficha", name="clinica_ficha_internacao", methods={"GET"})
     */
    public function fichaInternacao(
        int                    $id,
        EntityManagerInterface $em
    ): Response
    {
        $this->switchDB();
        $baseId = $this->getIdBase();
        $internacaoRepo = $this->getRepositorio(Internacao::class);
        $veterinarioRepo = $this->getRepositorio(Veterinario::class);

        $internacao = $internacaoRepo->findInternacaoCompleta($baseId, $id);
        if (!$internacao) {
            throw $this->createNotFoundException('A ficha de internação não foi encontrada.');
        }

        // --- TIMELINE ---
        $rows = $internacaoRepo->listarEventosPorInternacao($baseId, $id);
        $timeline = array_map(function (array $r) {
            try {
                $r['data_hora'] = !empty($r['data_hora']) ? new \DateTime($r['data_hora']) : new \DateTime();
            } catch (\Exception $e) {
                $r['data_hora'] = new \DateTime();
            }
            $r['titulo'] = $r['titulo'] ?? '—';
            $r['descricao'] = $r['descricao'] ?? '';
            $r['tipo'] = (string)($r['tipo'] ?? 'internacao');
            return $r;
        }, $rows);
        usort($timeline, fn($a, $b) => $b['data_hora'] <=> $a['data_hora']);

        // --- PRESCRIÇÕES ---
        // IMPORTANTE: Usa método customizado que filtra EXPLICITAMENTE por internacaoId
        // para evitar carregar prescrições de outras internações
        $medicamentos = $em->getRepository(Medicamento::class)->findAll();
        $prescricoes = $em->getRepository(InternacaoPrescricao::class)->findByInternacao($id);

        // --- CALENDÁRIO ---
        // Busca TODOS os eventos de prescrição desta internação de uma vez
        $todosEventos = $em->getRepository(\App\Entity\InternacaoEvento::class)
            ->createQueryBuilder('e')
            ->where('e.internacaoId = :internacaoId')
            ->andWhere('e.tipo = :tipo')
            ->setParameter('internacaoId', $id)
            ->setParameter('tipo', 'prescricao')
            ->orderBy('e.dataHora', 'ASC')
            ->getQuery()
            ->getResult();

        // Busca todas as execuções de uma vez
        $eventoIds = array_map(fn($e) => $e->getId(), $todosEventos);
        $execucoes = [];
        if (!empty($eventoIds)) {
            $execucoesResult = $em->getRepository(\App\Entity\InternacaoExecucao::class)
                ->createQueryBuilder('ex')
                ->where('ex.prescricaoId IN (:eventoIds)')
                ->setParameter('eventoIds', $eventoIds)
                ->getQuery()
                ->getResult();

            // Indexa por prescricaoId
            foreach ($execucoesResult as $exec) {
                $execucoes[$exec->getPrescricaoId()] = $exec;
            }
        }

        // Processa todos os eventos
        $events = [];
        foreach ($todosEventos as $evento) {
            $execucao = $execucoes[$evento->getId()] ?? null;

            $cor = '#0d6efd';
            $habilitaModal = true;
            if ($execucao && $execucao->getStatus() == 'confirmado') {
                $habilitaModal = false;
                $cor = 'green';
            }

            $events[] = [
                'title' => $evento->getTitulo(),
                'start' => $evento->getDataHora()->format(\DateTime::ATOM),
                'end' => (clone $evento->getDataHora())->modify('+30 minutes')->format(\DateTime::ATOM),
                'color' => $cor,
                'prescricao_id' => $evento->getId(),
                'habilita_modal' => $habilitaModal,
            ];
        }

        // --- VETERINÁRIOS --- (apenas ativos para novos lançamentos; histórico preservado nas execuções)
        $veterinarios = $veterinarioRepo->findBy(['estabelecimentoId' => $baseId, 'status' => 'ativo']);

        $data = [];
        $data['internacao'] = $internacao;
        $data['timeline'] = $timeline;
        $data['medicamentos'] = $medicamentos;
        $data['prescricoes'] = $prescricoes;
        $data['calendario_prescricoes'] = $events;
        $data['veterinarios'] = $veterinarios;
        // dd($data);
        return $this->render('clinica/ficha_internacao.html.twig', $data);
    }

    /**
     * @Route("/internacao/{id}/acao/{acao}", name="clinica_internacao_acao", methods={"POST"})
     */
    public function finalizarInternacao(
        int $id,
        string $acao,
        Request $request
    ): JsonResponse {
        $this->switchDB();
        $baseId = $this->getIdBase();
        $internacaoRepo = $this->getRepositorio(Internacao::class);
        $boxRepo = $this->getRepositorio(Box::class);

        if (!$this->isCsrfTokenValid('internacao_acao_' . $id, $request->get('_token'))) {
            return $this->json(['ok' => false, 'msg' => 'Token inválido.'], 400);
        }
 
        $internacao = $internacaoRepo->buscarPorId($baseId, $id);
        if (!$internacao) {
            return $this->json(['ok' => false, 'msg' => 'Internação não encontrada.'], 404);
        }
 
        // ✅ CORREÇÃO: Todos os finais têm status 'finalizada'
        $acoesValidas = [
            'alta'     => [
                'status'          => 'finalizada',  // ✅ Status final
                'motivo_conclusao'=> 'alta',        // 🆕 Motivo
                'titulo'          => 'Alta concedida',
                'descricao'       => 'Internação finalizada por alta'
            ],
            'obito'    => [
                'status'          => 'finalizada',  // ✅ MUDADO de 'obito' para 'finalizada'
                'motivo_conclusao'=> 'obito',       // 🆕 Motivo
                'titulo'          => 'Óbito registrado',
                'descricao'       => 'Internação finalizada por óbito'
            ],
            'cancelar' => [
                'status'          => 'finalizada',  // ✅ MUDADO de 'cancelada' para 'finalizada'
                'motivo_conclusao'=> 'cancelada',   // 🆕 Motivo
                'titulo'          => 'Internação cancelada',
                'descricao'       => 'Internação cancelada pelo sistema'
            ],
            'box'      => [
                'status'          => 'ativa',       // Muda apenas box, não finaliza
                'motivo_conclusao'=> null,
                'titulo'          => 'Box alterado',
                'descricao'       => 'Box de internação atualizado'
            ],
            'editar'   => [
                'status'          => 'ativa',       // Apenas edição, não finaliza
                'motivo_conclusao'=> null,
                'titulo'          => 'Internação editada',
                'descricao'       => 'Dados da internação foram atualizados'
            ],
        ];
 
        if (!isset($acoesValidas[$acao])) {
            return $this->json(['ok' => false, 'msg' => 'Ação inválida.'], 400);
        }
 
        // ✅ CORREÇÃO: Valida se já foi finalizada (usando 'finalizada' como status final)
        if ($internacao['status'] === 'finalizada') {
            $motivo = $internacao['motivo_conclusao'] ?? 'desconhecido';
            return $this->json([
                'ok'  => false,
                'msg' => 'Esta internação já foi finalizada (' . $motivo . ').',
            ]);
        }
 
        $acaoInfo = $acoesValidas[$acao];
 
        // ✅ CORREÇÃO: Atualiza status E adiciona data/motivo de conclusão
        $internacaoRepo->atualizarStatus($baseId, $id, $acaoInfo['status']);
        
        // 🆕 Registra quando e por que foi finalizado
        if ($acaoInfo['status'] === 'finalizada') {
            $internacaoRepo->atualizarConclusao(
                $baseId,
                $id,
                new \DateTime(),
                $acaoInfo['motivo_conclusao']
            );
        }
 
        // ── Libera o box automaticamente ao encerrar a internação ─────
        // ✅ CORREÇÃO: Agora verifica status === 'finalizada' (não lista de vários status)
        if ($acaoInfo['status'] === 'finalizada') {
            $boxNumero = $internacao['box'] ?? '';
            if ($boxNumero !== '') {
                $boxRepo->liberar($baseId, $boxNumero);
            }
        }
 
        // ── Óbito: marca o pet como falecido ────────────────────────
        if ($acaoInfo['motivo_conclusao'] === 'obito') {
            $this->getRepositorio(Pet::class)->marcarObito(
                $baseId,
                (int) $internacao['pet_id'],
                new \DateTime()
            );
        }
 
        // ── Registra evento no histórico ───────────────────────────
        $internacaoRepo->inserirEvento(
            $baseId,
            $id,
            (int) $internacao['pet_id'],
            ucfirst($acao),
            $acaoInfo['titulo'],
            $acaoInfo['descricao'],
            new \DateTime()
        );
 
        return $this->json(['ok' => true]);
    }


    /**
     * @Route("/internacao/{id}/prescricao/nova", name="clinica_internacao_prescricao_nova", methods={"GET","POST"})
     */
    public function novaPrescricao(
        int                    $id,
        Request                $request,
        EntityManagerInterface $em
    ): Response
    {
        $this->switchDB();
        $baseId = $this->getIdBase();
        $internacaoRepo = $this->getRepositorio(\App\Entity\Internacao::class);

        if ($request->isMethod('GET')) {
            return $this->redirectToRoute('clinica_ficha_internacao', ['id' => $id]);
        }

        try {
            $internacao = $em->getRepository(Internacao::class)->find($id);
            if (!$internacao) {
                return $this->json(['ok' => false, 'msg' => 'Internação não encontrada.'], 404);
            }

            $medicamentoId = (int)$request->get('medicamentoId');
            $dose = trim((string)$request->get('dose'));
            $frequenciaHoras = (int)$request->get('frequencia_horas');
            $duracaoDias = (int)$request->get('duracao_dias');
            $dataHoraPrimeiraDose = $request->get('data_hora_primeira_dose');

            if (!$medicamentoId || empty($dose) || $frequenciaHoras <= 0 || $duracaoDias <= 0 || empty($dataHoraPrimeiraDose)) {
                return $this->json(['ok' => false, 'msg' => 'Campos obrigatórios faltando.'], 400);
            }

            $medicamento = $em->getRepository(Medicamento::class)->find($medicamentoId);
            if (!$medicamento) {
                return $this->json(['ok' => false, 'msg' => 'Medicamento não encontrado.'], 404);
            }

            // --- Cria a prescrição ---
            $prescricao = new InternacaoPrescricao();
            $prescricao->setInternacaoId($internacao->getId());
            $prescricao->setMedicamento($medicamento);
            $prescricao->setDescricao($medicamento->getNome());
            $prescricao->setDose($dose);

            // Salva tanto a string "bonita" quanto os valores numéricos
            $prescricao->setFrequencia(sprintf('a cada %d horas por %d dias', $frequenciaHoras, $duracaoDias));
            $prescricao->setFrequenciaHoras($frequenciaHoras);
            $prescricao->setDuracaoDias($duracaoDias);

            $prescricao->setDataHora(new \DateTime($dataHoraPrimeiraDose));
            $prescricao->setCriadoEm(new \DateTime());


            $em->persist($prescricao);
            $em->flush();

            // --- Cria eventos da timeline ---
            $petId = method_exists($internacao, 'getPetId')
                ? $internacao->getPetId()
                : ($internacao->getPet() ? $internacao->getPet()->getId() : null);

            if ($petId) {
                $numDoses = ($duracaoDias * 24) / $frequenciaHoras;

                for ($i = 0; $i < $numDoses; $i++) {
                    $dataDose = (new \DateTime($dataHoraPrimeiraDose))->modify('+' . ($i * $frequenciaHoras) . ' hours');

                    $descricaoEvento = sprintf(
                        "Medicamento: %s | Dose: %s | Frequência: %s",
                        $medicamento->getNome(),
                        $dose,
                        $prescricao->getFrequencia()
                    );

                    $internacaoRepo->inserirEvento(
                        $baseId,
                        $id,
                        $petId,
                        'prescricao',
                        $medicamento->getNome(),
                        $descricaoEvento,
                        $dataDose
                    );
                }
            }

            return $this->json(['ok' => true, 'msg' => 'Prescrição salva com sucesso!']);

        } catch (\Exception $e) {
            return $this->json([
                'ok' => false,
                'msg' => 'Erro interno: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Apaga uma prescrição por completo: a prescrição em si, todos os eventos
     * (horários agendados) e todas as execuções (confirmações) que já foram
     * registradas para ela. Útil quando o veterinário prescreveu errado e
     * precisa refazer, mesmo depois de já ter administrado alguma dose.
     *
     * @Route("/internacao/{id}/prescricao/{prescricaoId}/apagar", name="clinica_internacao_prescricao_apagar", methods={"POST"})
     */
    public function apagarPrescricao(
        int                    $id,
        int                    $prescricaoId,
        Request                $request,
        EntityManagerInterface $em
    ): JsonResponse {
        $this->switchDB();
        $baseId = $this->getIdBase();

        if (!$this->isCsrfTokenValid('prescricao_apagar_' . $prescricaoId, $request->get('_token'))) {
            return $this->json(['ok' => false, 'msg' => 'Token inválido.'], 400);
        }

        $prescricao = $em->getRepository(InternacaoPrescricao::class)
            ->findByIdAndInternacao($prescricaoId, $id);

        if (!$prescricao) {
            return $this->json(['ok' => false, 'msg' => 'Prescrição não encontrada.'], 404);
        }

        try {
            // 1. Eventos (ou seja, horários agendados) desta prescrição.
            $eventos = $em->getRepository(\App\Entity\InternacaoEvento::class)
                ->createQueryBuilder('e')
                ->where('e.internacaoId = :internacaoId')
                ->andWhere('e.tipo = :tipo')
                ->andWhere('e.titulo = :titulo')
                ->setParameter('internacaoId', $id)
                ->setParameter('tipo', 'prescricao')
                ->setParameter('titulo', $prescricao->getMedicamento()->getNome())
                ->getQuery()
                ->getResult();

            $eventoIds = array_map(fn($e) => $e->getId(), $eventos);

            // 2. Execuções confirmadas associadas aos eventos.
            if (!empty($eventoIds)) {
                $em->getRepository(\App\Entity\InternacaoExecucao::class)
                    ->createQueryBuilder('ex')
                    ->delete()
                    ->where('ex.prescricaoId IN (:ids)')
                    ->setParameter('ids', $eventoIds)
                    ->getQuery()
                    ->execute();
            }

            // 3. Remove os eventos.
            foreach ($eventos as $evento) {
                $em->remove($evento);
            }

            // 4. Remove a própria prescrição.
            $em->remove($prescricao);

            $em->flush();

            return $this->json(['ok' => true, 'msg' => 'Prescrição apagada.']);
        } catch (\Throwable $e) {
            return $this->json([
                'ok'  => false,
                'msg' => 'Erro ao apagar prescrição: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * @Route("/internacao/{id}/prescricao/{eventoId}/executar", name="clinica_internacao_prescricao_executar", methods={"POST"})
     */
    public function executarPrescricao(
        int                    $id,
        int                    $eventoId,
        Request                $request,
        EntityManagerInterface $em
    ): JsonResponse
    {
        $this->switchDB();
        $baseId = $this->getIdBase();

        $horaAplicacao = $request->get('hora_aplicacao');
        $veterinarioId = (int)$request->get('veterinario_id');
        $anotacoes = $request->get('anotacoes');

        if (!$horaAplicacao || !$veterinarioId) {
            return $this->json(['ok' => false, 'msg' => 'Preencha hora e veterinário.'], 400);
        }

        try {

            // Busca o veterinário
            $veterinario = $em->getRepository(\App\Entity\Veterinario::class)->find($veterinarioId);
            if (!$veterinario) {
                return $this->json(['ok' => false, 'msg' => 'Veterinário não encontrado.'], 404);
            }

            // Cria entidade de execução
            $execucao = new InternacaoExecucao();
            $execucao->setInternacaoId($id);
            $execucao->setPrescricaoId($eventoId);
            $execucao->setVeterinario($veterinario);
            $execucao->setDataExecucao(new \DateTime($horaAplicacao));
            $execucao->setStatus('confirmado'); // marca como confirmado
            $execucao->setAnotacoes($anotacoes);

            $em->persist($execucao);
            $em->flush();

            return $this->json(['ok' => true, 'msg' => 'Medicação confirmada com sucesso!']);

        } catch (\Exception $e) {
            return $this->json(['ok' => false, 'msg' => 'Erro: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @Route("/internacao/{id}/evento/{eventoId}/executar", name="clinica_internacao_evento_executar", methods={"POST"})
     */
    public function executarEvento(
        int                    $id,
        int                    $eventoId,
        Request                $request,
        EntityManagerInterface $em
    ): JsonResponse
    {
        $this->switchDB();
        $baseId = $this->getIdBase();

        $horaAplicacao = $request->get('hora_aplicacao');
        $veterinarioId = (int)$request->get('veterinario_id', 1);
        $anotacoes = $request->get('anotacoes', 'Confirmado via sistema');

        try {
            // Busca o veterinário
            $veterinario = $em->getRepository(\App\Entity\Veterinario::class)->find($veterinarioId);
            if (!$veterinario) {
                // Se não encontrar, usa o primeiro veterinário disponível
                $veterinario = $em->getRepository(\App\Entity\Veterinario::class)->findOneBy([]);
            }

            // Cria entidade de execução
            $execucao = new InternacaoExecucao();
            $execucao->setInternacaoId($id);
            $execucao->setPrescricaoId($eventoId);
            if ($veterinario) {
                $execucao->setVeterinario($veterinario);
            }
            $execucao->setDataExecucao(new \DateTime($horaAplicacao ?: 'now'));
            $execucao->setStatus('confirmado');
            $execucao->setAnotacoes($anotacoes);

            $em->persist($execucao);
            $em->flush();

            return $this->json(['ok' => true, 'msg' => 'Medicação confirmada com sucesso!']);

        } catch (\Exception $e) {
            return $this->json(['ok' => false, 'msg' => 'Erro: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @Route("/internacao/medicamento/novo", name="clinica_internacao_medicamento_novo", methods={"POST"})
     */
    public function novoMedicamentoViaInternacao(Request $request, EntityManagerInterface $em): JsonResponse
    {
        $this->switchDB();
        $baseId = $this->getIdBase();

        $nome = trim((string)$request->get('nome'));
        $via = trim((string)$request->get('via'));
        $concentracao = trim((string)$request->get('concentracao'));

        if (empty($nome)) {
            return $this->json(['ok' => false, 'msg' => 'O nome do medicamento é obrigatório.']);
        }

        try {
            $medicamento = new Medicamento();
            $medicamento->setNome($nome);
            $medicamento->setVia($via);
            $medicamento->setConcentracao($concentracao);

            $em->persist($medicamento);
            $em->flush();
            return $this->json(['ok' => true, 'msg' => 'Medicamento cadastrado com sucesso!']);
        } catch (\Exception $e) {
            return $this->json(['ok' => false, 'msg' => 'Erro ao salvar o medicamento: ' . $e->getMessage()]);
        }

    }
}